
package GUI.Profile;

import GUI.Dashboard.AdministratorDashboard;
import GUI.Dashboard.OfficerDashboard;
import GUI.Dashboard.SalespersonDashboard;
import static InputOutput.CSVDataReader.readUsersFromCSV;
import UserProfile.Session.SessionManager;
import UserProfile.Session.SessionWorker;
import UserProfile.User;
import static Validation.LoginValidation.validateWorkerEmail;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static searchAlgo.CSVSearch.findUserByEmail;

public class FindWorkerProfile extends javax.swing.JFrame {

    /**
     * Creates new form ManageWorkerProfile
     */
    public FindWorkerProfile() {
        initComponents();
        populateTable();
    }
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tf_Email = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btn_manageProfile = new javax.swing.JButton();
        btn_return = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 550));

        jPanel1.setBackground(new java.awt.Color(214, 140, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 207, 149));

        jLabel1.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(53, 79, 82));
        jLabel1.setText("Manage worker");

        tf_Email.setBackground(new java.awt.Color(214, 140, 51));
        tf_Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_EmailActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(53, 79, 82));
        jLabel2.setText("Profile");

        jLabel3.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(53, 79, 82));
        jLabel3.setText("Enter Worker Email");

        btn_manageProfile.setBackground(new java.awt.Color(102, 204, 255));
        btn_manageProfile.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        btn_manageProfile.setForeground(new java.awt.Color(0, 0, 0));
        btn_manageProfile.setText("Manage Profile");
        btn_manageProfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_manageProfileActionPerformed(evt);
            }
        });

        btn_return.setBackground(new java.awt.Color(53, 79, 82));
        btn_return.setForeground(new java.awt.Color(255, 0, 0));
        btn_return.setText("Return");
        btn_return.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_returnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(jLabel2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(btn_manageProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(btn_return)))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(56, 56, 56)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_manageProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btn_return)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 360, 500);

        jPanel3.setBackground(new java.awt.Color(53, 79, 82));

        jTable1.setBackground(new java.awt.Color(255, 207, 149));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Email", "Role"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(52, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(360, 0, 440, 500);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 178, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 172, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tf_EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_EmailActionPerformed
       
    }//GEN-LAST:event_tf_EmailActionPerformed

    private void btn_manageProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_manageProfileActionPerformed
        if(tf_Email.getText().equals("")){
            JOptionPane.showMessageDialog(this,"Enter an Email!!");
        }else{
          
          ArrayList<User> users_arraylist = readUsersFromCSV("Users.csv");  
          boolean email_is_found = validateWorkerEmail(users_arraylist,tf_Email.getText());
          
          if(email_is_found){
              User selected_user = findUserByEmail(users_arraylist,tf_Email.getText());
              //proceed if the selected user exists
              if (selected_user != null) {
                    //Condition that only permits non admin user profile to be modified 
                    if(!"Administrator".equals(selected_user.getRole())){
                        //set the session worker to the selected worker(different from session manager)
                        SessionWorker.setCurrentUser(selected_user);
                        //move to the manage worker profile page 
                        ManageWorkerProfile worker_profile_frame = new ManageWorkerProfile();
                        worker_profile_frame.setVisible(true);
                        worker_profile_frame.pack();
                        worker_profile_frame.setLocationRelativeTo(null);
                        this.dispose();
                    }else{
                        // display message when an admin email is entered
                        JOptionPane.showMessageDialog(this,"Admin profile cannot be modified");
                    }
              }
        } else {
            // Login failed, display an error message or take appropriate action
            JOptionPane.showMessageDialog(this,"Email does not Exist!");
        }
          }
    }//GEN-LAST:event_btn_manageProfileActionPerformed

    private void btn_returnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_returnActionPerformed
        User toReturn_user = SessionManager.getCurrentUser();
        
        String toReturn_userRole = toReturn_user.getRole();
        
        switch(toReturn_userRole){
            case "Administrator" :
                AdministratorDashboard admin_dashboard_frame = new AdministratorDashboard();
                admin_dashboard_frame.setVisible(true);
                admin_dashboard_frame.pack();
                admin_dashboard_frame.setLocationRelativeTo(null);
                this.dispose();
                break;
                
            case "Officer" :
                OfficerDashboard officer_dashboard_frame = new OfficerDashboard();
                officer_dashboard_frame.setVisible(true);
                officer_dashboard_frame.pack();
                officer_dashboard_frame.setLocationRelativeTo(null);
                this.dispose();
                break;
                
            case "Salesperson" :
                SalespersonDashboard salesperson_dashboard_frame = new SalespersonDashboard();
                salesperson_dashboard_frame.setVisible(true);
                salesperson_dashboard_frame.pack();
                salesperson_dashboard_frame.setLocationRelativeTo(null);
                this.dispose();
                break;
            }
    }//GEN-LAST:event_btn_returnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FindWorkerProfile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FindWorkerProfile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FindWorkerProfile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FindWorkerProfile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                FindWorkerProfile profile = new FindWorkerProfile();
                profile.setVisible(true);
            }
        });
        
    }
    
    public void populateTable() {
        ArrayList<User> users_arraylist = readUsersFromCSV("Users.csv");
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();

        for (User user : users_arraylist) {
            
            // lists users who are not administrators
            if(!"Administrator".equals(user.getRole())){
            String Email = user.getEmail_Address();
            String Role = user.getRole();
            
            String data[] = {Email,Role};
            tblModel.addRow(data);
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_manageProfile;
    private javax.swing.JButton btn_return;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField tf_Email;
    // End of variables declaration//GEN-END:variables
}
