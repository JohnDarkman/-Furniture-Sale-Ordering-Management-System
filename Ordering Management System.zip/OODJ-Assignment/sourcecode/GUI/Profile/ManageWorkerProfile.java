
package GUI.Profile;

import GUI.Dashboard.AdministratorDashboard;
import GUI.Dashboard.OfficerDashboard;
import GUI.Dashboard.SalespersonDashboard;
import static InputOutput.CSVDataReader.readUsersFromCSV;
import UserProfile.Session.SessionManager;
import UserProfile.Session.SessionWorker;
import UserProfile.User;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ManageWorkerProfile extends javax.swing.JFrame {

    public ManageWorkerProfile() {
        initComponents();
        populateUserInformation();
    }

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btn_edit = new javax.swing.JButton();
        btn_save = new javax.swing.JButton();
        tf_workerprofile_username = new javax.swing.JTextField();
        tf_workerprofile_email = new javax.swing.JTextField();
        tf_workerprofile_password = new javax.swing.JTextField();
        cb_role = new javax.swing.JComboBox<>();
        btn_ReturnToMenu = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 550));

        jPanel1.setBackground(new java.awt.Color(214, 140, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 207, 149));

        jLabel1.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(53, 79, 82));
        jLabel1.setText("Manage Worker Profile");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addComponent(jLabel1)
                .addContainerGap(152, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel1)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 800, 110);

        jPanel3.setBackground(new java.awt.Color(53, 79, 82));

        jLabel2.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 207, 149));
        jLabel2.setText("Username");

        jLabel3.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 207, 149));
        jLabel3.setText("Email");

        jLabel4.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 207, 149));
        jLabel4.setText("Password");

        jLabel5.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 207, 149));
        jLabel5.setText("Role");

        btn_edit.setBackground(new java.awt.Color(102, 204, 255));
        btn_edit.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        btn_edit.setForeground(new java.awt.Color(0, 0, 0));
        btn_edit.setText("Edit");
        btn_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editActionPerformed(evt);
            }
        });

        btn_save.setBackground(new java.awt.Color(255, 207, 149));
        btn_save.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 18)); // NOI18N
        btn_save.setForeground(new java.awt.Color(53, 79, 82));
        btn_save.setText("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        tf_workerprofile_username.setBackground(new java.awt.Color(255, 255, 204));
        tf_workerprofile_username.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tf_workerprofile_username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_workerprofile_usernameActionPerformed(evt);
            }
        });

        tf_workerprofile_email.setBackground(new java.awt.Color(255, 255, 204));
        tf_workerprofile_email.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        tf_workerprofile_password.setBackground(new java.awt.Color(255, 255, 204));
        tf_workerprofile_password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        cb_role.setBackground(new java.awt.Color(255, 255, 204));
        cb_role.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cb_role.setForeground(new java.awt.Color(0, 0, 0));
        cb_role.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrator", "Officer", "Salesperson" }));

        btn_ReturnToMenu.setBackground(new java.awt.Color(255, 207, 149));
        btn_ReturnToMenu.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        btn_ReturnToMenu.setForeground(new java.awt.Color(53, 79, 82));
        btn_ReturnToMenu.setText("Back");
        btn_ReturnToMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ReturnToMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(95, 95, 95)
                        .addComponent(tf_workerprofile_username, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(btn_ReturnToMenu))
                        .addGap(100, 100, 100)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_workerprofile_email, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_workerprofile_password, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(btn_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(94, 94, 94)
                                .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cb_role, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(189, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tf_workerprofile_username, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_workerprofile_email, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tf_workerprofile_password, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(cb_role, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_ReturnToMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 110, 800, 390);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 366, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 222, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editActionPerformed
        tf_workerprofile_username.setEditable(true);
        tf_workerprofile_password.setEditable(true);
        cb_role.setEditable(true);
    }//GEN-LAST:event_btn_editActionPerformed

    private void tf_workerprofile_usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_workerprofile_usernameActionPerformed
    }//GEN-LAST:event_tf_workerprofile_usernameActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        User current_main_user = SessionManager.getCurrentUser();
        
        // Obtain Username, email, password, and role
        String new_username = tf_workerprofile_username.getText();
        String email = tf_workerprofile_email.getText();
        String new_password = tf_workerprofile_password.getText();
        String new_role = (String )cb_role.getSelectedItem();
        
        // Update the user details in the CSV file
        updateProfileInCSV(new_username, email, new_password, new_role);

        // Update Session Manager
        updateSessionWorker(new_username, email, new_password, new_role);

        // Make the fields non-editable again
        tf_workerprofile_username.setEditable(false);
        tf_workerprofile_password.setEditable(false);
        cb_role.setEditable(false);
        
        //return user to respective dashboard 
        switch(current_main_user.getRole()){
            case "Administrator" :
                AdministratorDashboard admin_dashboard_frame = new AdministratorDashboard();
                admin_dashboard_frame.setVisible(true);
                admin_dashboard_frame.pack();
                admin_dashboard_frame.setLocationRelativeTo(null);
                this.dispose();
                break;
                
            case "Officer" :
                OfficerDashboard officer_dashboard_frame = new OfficerDashboard();
                officer_dashboard_frame.setVisible(true);
                officer_dashboard_frame.pack();
                officer_dashboard_frame.setLocationRelativeTo(null);
                this.dispose();
                break;
                
            case "Salesperson" :
                SalespersonDashboard salesperson_dashboard_frame = new SalespersonDashboard();
                salesperson_dashboard_frame.setVisible(true);
                salesperson_dashboard_frame.pack();
                salesperson_dashboard_frame.setLocationRelativeTo(null);
                this.dispose();
                break;
            }
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_ReturnToMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ReturnToMenuActionPerformed
        AdministratorDashboard admin_dashboard_frame = new AdministratorDashboard();
                admin_dashboard_frame.setVisible(true);
                admin_dashboard_frame.pack();
                admin_dashboard_frame.setLocationRelativeTo(null);
                this.dispose();
        
    }//GEN-LAST:event_btn_ReturnToMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageWorkerProfile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageWorkerProfile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageWorkerProfile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageWorkerProfile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageWorkerProfile().setVisible(true);
            }
        });
    }
    
    private void populateUserInformation() {
        User currentProfileUser = SessionWorker.getCurrentUser();
        
        if (currentProfileUser != null) {
            String username = currentProfileUser.getUsername();
            tf_workerprofile_username.setText(username);
            tf_workerprofile_username.setEditable(false);

            String email = currentProfileUser.getEmail_Address();
            tf_workerprofile_email.setText(email);
            tf_workerprofile_email.setEditable(false);

            String password = currentProfileUser.getPassword();
            tf_workerprofile_password.setText(password);
            tf_workerprofile_password.setEditable(false);
            
            String role = currentProfileUser.getRole();
            cb_role.setSelectedItem(role);
            cb_role.setEditable(false);
        }
    }
    
    private boolean updateProfileInCSV(String newUsername, String email, String newPassword, String newRole) {
    User currentUser = SessionWorker.getCurrentUser();

    if (currentUser != null) {
        currentUser.setUsername(newUsername);
        currentUser.setEmail_Address(email);
        currentUser.setPassword(newPassword);
        currentUser.setRole(newRole);
        
         ArrayList<User> csv_users = readUsersFromCSV("Users.csv");
         // Find the index of the user in the list
        int index = -1;
        for (int i = 0; i < csv_users.size(); i++) {
            if (csv_users.get(i).getEmail_Address().equals(currentUser.getEmail_Address())) {
                index = i;
                break;
            }
        }

        // Update the user in the list if found
        if (index != -1) {
            csv_users.set(index, currentUser);

            // Write the updated list back to the CSV file
            writeUsersToCSV("Users.csv", csv_users);

            return true; // Return true to indicate successful update
        } else {
            // Handle the case where the user is not found in the CSV
            System.out.println("User not found in CSV");
            return false;
        }
    }

    return false; // Handle the case where the current user is null
}
   
private void writeUsersToCSV(String filename, ArrayList<User> users) {
    try (FileWriter csvWriter = new FileWriter(filename)) {
        for (User user : users) {
            csvWriter.append(user.getUsername())
                    .append(",")
                    .append(user.getEmail_Address())
                    .append(",")
                    .append(user.getPassword())
                    .append(",")
                    .append(user.getRole())
                    .append("\n");
        }
        csvWriter.flush();
    } catch (IOException e) {
        e.printStackTrace(); // Handle IOException more appropriately, like logging or displaying an error message.
    }
}



private void updateSessionWorker(String newUsername, String newEmail, String newPassword, String newRole) {
    // Update the SessionManager with the new user details
    User currentUser = SessionWorker.getCurrentUser();
    if (currentUser != null) {
        currentUser.setUsername(newUsername);
        currentUser.setEmail_Address(newEmail);
        currentUser.setPassword(newPassword);
        currentUser.setRole(newRole);
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_ReturnToMenu;
    private javax.swing.JButton btn_edit;
    private javax.swing.JButton btn_save;
    private javax.swing.JComboBox<String> cb_role;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField tf_workerprofile_email;
    private javax.swing.JTextField tf_workerprofile_password;
    private javax.swing.JTextField tf_workerprofile_username;
    // End of variables declaration//GEN-END:variables
}
