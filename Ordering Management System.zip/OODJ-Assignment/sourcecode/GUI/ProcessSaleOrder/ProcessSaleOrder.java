
package GUI.ProcessSaleOrder;

import GUI.Dashboard.OfficerDashboard;
import GUI.ManageSaleOrderQuotation.ModifySaleOrderQuotation;
import static InputOutput.CSVDataReader.readReportsFromCSV;
import static InputOutput.CSVDataReader.readSaleOrderQuotationFromCSV;
import static InputOutput.CSVWriter.writeApprovalReportListToCSV;
import static InputOutput.CSVWriter.writeSaleOrderListToCSV;
import Reports.ApprovalReport;
import SaleOrder.SaleOrderQuotation;
import UserProfile.Session.SessionSalesOrder;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static searchAlgo.CSVSearch.findApprovalReportByOrderID;
import static searchAlgo.CSVSearch.findSaleOrderByOrderID;

/**
 *
 * @author USSER
 */
public class ProcessSaleOrder extends javax.swing.JFrame {

    /**
     * Creates new form GenerateInvoice
     */
    public ProcessSaleOrder() {
        initComponents();
        populateExistingTable();
    }

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btn_modify = new javax.swing.JButton();
        btn_remove_order = new javax.swing.JButton();
        btn_generate_invoice = new javax.swing.JButton();
        btn_return = new javax.swing.JButton();
        tf_sale_order_id = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(850, 550));

        jPanel1.setBackground(new java.awt.Color(214, 140, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));

        jPanel2.setBackground(new java.awt.Color(255, 207, 149));

        jPanel3.setBackground(new java.awt.Color(53, 79, 82));

        jTable1.setBackground(new java.awt.Color(255, 207, 149));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Order ID", "Customer"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btn_modify.setBackground(new java.awt.Color(255, 207, 149));
        btn_modify.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        btn_modify.setForeground(new java.awt.Color(53, 79, 82));
        btn_modify.setText("Modify");
        btn_modify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modifyActionPerformed(evt);
            }
        });

        btn_remove_order.setBackground(new java.awt.Color(255, 207, 149));
        btn_remove_order.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_remove_order.setForeground(new java.awt.Color(53, 79, 82));
        btn_remove_order.setText("Delete");
        btn_remove_order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_remove_orderActionPerformed(evt);
            }
        });

        btn_generate_invoice.setBackground(new java.awt.Color(255, 207, 149));
        btn_generate_invoice.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        btn_generate_invoice.setForeground(new java.awt.Color(53, 79, 82));
        btn_generate_invoice.setText("Generate Invoice");
        btn_generate_invoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_generate_invoiceActionPerformed(evt);
            }
        });

        btn_return.setBackground(new java.awt.Color(255, 207, 149));
        btn_return.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        btn_return.setForeground(new java.awt.Color(53, 79, 82));
        btn_return.setText("Back");
        btn_return.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_returnActionPerformed(evt);
            }
        });

        tf_sale_order_id.setBackground(new java.awt.Color(255, 255, 204));

        jLabel2.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 207, 149));
        jLabel2.setText("Enter Order ID");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 39, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(tf_sale_order_id, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(btn_modify, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_remove_order, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btn_generate_invoice, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(btn_return, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 363, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tf_sale_order_id, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_modify, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_remove_order, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(btn_generate_invoice, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(btn_return, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)))
                .addContainerGap(107, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(53, 79, 82));
        jLabel1.setText("Process Sale Order");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(252, 252, 252)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 822, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 99, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 93, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_returnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_returnActionPerformed
        OfficerDashboard officer_dashboard_frame = new OfficerDashboard();
        officer_dashboard_frame.setVisible(true);
        officer_dashboard_frame.pack();
        officer_dashboard_frame.setLocationRelativeTo(null);
        this.dispose();
        
    }//GEN-LAST:event_btn_returnActionPerformed

    private void btn_generate_invoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_generate_invoiceActionPerformed
        
        //create arraylist for saleorder
        ArrayList<SaleOrderQuotation> order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        
        //create arraylist for approval report
        ArrayList<ApprovalReport> approval_report_list = readReportsFromCSV("ApprovalReportData.csv");
        
        // get text field data
        String search_sale_order_id = tf_sale_order_id.getText();
        //find sale order based on id and instantiate an object of it
        SaleOrderQuotation order = findSaleOrderByOrderID(order_list,search_sale_order_id);
        //set the order as the current sales order
        SessionSalesOrder.setCurrentOrder(order);
        
        ApprovalReport report = findApprovalReportByOrderID(approval_report_list,search_sale_order_id);
        
        if(report.getStatus().equals("Approved")){
            //verifies if the order id in both the saleorderdata csv file and approvalreportdata csv file matches and the status are approved
            if(order.getSale_order_ID().equals(report.getSaleOrderID())){
                //set current session sale order as the order entered in the search bar
                SessionSalesOrder.setCurrentOrder(order);
        
                //move to invoice screen
                Invoice invoice_frame = new Invoice();
                invoice_frame.setVisible(true);
                invoice_frame.pack();
                invoice_frame.setLocationRelativeTo(null);
                this.dispose();
            }
        }else{
            // Displays message "Sale order has not been approved!"
            JOptionPane.showMessageDialog(this,"Sale order has not been approved!");
        }
    }//GEN-LAST:event_btn_generate_invoiceActionPerformed

    private void btn_remove_orderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_remove_orderActionPerformed
        System.out.println("Btn remove debug line");
        
        String order_id = tf_sale_order_id.getText();
        
        ArrayList<SaleOrderQuotation> sales_order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        
        ArrayList<ApprovalReport> approval_report_list = readReportsFromCSV("ApprovalReportData.csv");
        
        deleteSaleOrderFromCSV(sales_order_list,order_id,"SaleOrderQuotationData.csv");
        
        deleteReportFromCSV(approval_report_list,order_id,"ApprovalReportData.csv");
        
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        tblModel.setRowCount(0); // Clear existing rows
        
        ArrayList<SaleOrderQuotation> new_sales_order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        
        for (SaleOrderQuotation order : new_sales_order_list) {
            
            String sale_order_id = order.getSale_order_ID();
            String customer_name = order.getCustomer_name();
            
            String data[] = {sale_order_id,customer_name};
            tblModel.addRow(data);
        }
    }//GEN-LAST:event_btn_remove_orderActionPerformed

    private void btn_modifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modifyActionPerformed
        
        if(!tf_sale_order_id.getText().equals("")){
        ArrayList<SaleOrderQuotation> sales_order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        
        String searched_sale_order_id = tf_sale_order_id.getText();
        
        SaleOrderQuotation selected_order = findSaleOrderByOrderID(sales_order_list,searched_sale_order_id);
        
        SessionSalesOrder.setCurrentOrder(selected_order);
        
        ModifySaleOrderQuotation modify_order_frame = new ModifySaleOrderQuotation();
        modify_order_frame.setVisible(true);
        modify_order_frame.pack();
        modify_order_frame.setLocationRelativeTo(null);
        this.dispose();
        }
        
        
    }//GEN-LAST:event_btn_modifyActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ProcessSaleOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ProcessSaleOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ProcessSaleOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ProcessSaleOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProcessSaleOrder().setVisible(true);
            }
        });
    }
    
    private void populateExistingTable() {
        // Method not yet made
        ArrayList<SaleOrderQuotation> sales_order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        tblModel.setRowCount(0); // Clear existing rows
        
        for (SaleOrderQuotation order : sales_order_list) {
            
            String order_id = order.getSale_order_ID();
            String customer_name = order.getCustomer_name();
            
            String data[] = {order_id,customer_name};
            tblModel.addRow(data);
            
        }
        
    }
    
    public void deleteSaleOrderFromCSV(ArrayList<SaleOrderQuotation> sale_order_quotation_list, String order_ID, String csvFileName) {
    // Find the index of the report to be deleted in the list
        System.out.println("DeleteSaleOrder debug line");
    
    int index = -1;
    for (int i = 0; i < sale_order_quotation_list.size(); i++) {
        SaleOrderQuotation order = sale_order_quotation_list.get(i);
        if (order.getSale_order_ID().equals(order_ID)) {
            index = i;
            break;
        }
    }
    
    // Delete the report from the list if found
    if (index != -1) {
        sale_order_quotation_list.remove(index);
        
        // Write the updated list back to the CSV file
        writeSaleOrderListToCSV(sale_order_quotation_list, csvFileName);
        System.out.println("Record Removed");
    } else {
        System.out.println("Report not found in the list.");
    }
}
    
    public void deleteReportFromCSV(ArrayList<ApprovalReport> approval_report_list, String order_ID, String csvFileName) {
    // Find the index of the report to be deleted in the list
        System.out.println("Delete report debug line");
    
    int index = -1;
    for (int i = 0; i < approval_report_list.size(); i++) {
        ApprovalReport report = approval_report_list.get(i);
        if (report.getSaleOrderID().equals(order_ID)) {
            index = i;
            break;
        }
    }
    
    // Delete the report from the list if found
    if (index != -1) {
        approval_report_list.remove(index);
        
        // Write the updated list back to the CSV file
        writeApprovalReportListToCSV(approval_report_list, csvFileName);
        System.out.println("Record Removed");
    } else {
        System.out.println("Report not found in the list.");
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_generate_invoice;
    private javax.swing.JButton btn_modify;
    private javax.swing.JButton btn_remove_order;
    private javax.swing.JButton btn_return;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField tf_sale_order_id;
    // End of variables declaration//GEN-END:variables
}
