
package GUI.ManageSaleOrderQuotation;

import GUI.Dashboard.SalespersonDashboard;
import static InputOutput.CSVDataReader.readReportsFromCSV;
import static InputOutput.CSVDataReader.readSaleOrderQuotationFromCSV;
import static InputOutput.CSVWriter.writeSaleOrderListToCSV;
import static InputOutput.CSVWriter.writeApprovalReportListToCSV;
import Reports.ApprovalReport;
import SaleOrder.SaleOrderQuotation;
import UserProfile.Session.SessionSalesOrder;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import static searchAlgo.CSVSearch.findSaleOrderByOrderID;

public class ManageSaleOrderQuotationFrame extends javax.swing.JFrame {

    /**
     * Creates new form ManageSaleOrderQuotationFrame
     */
    public ManageSaleOrderQuotationFrame() {
        initComponents();
        populateExistingTable();
    }

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btn_create_new_order = new javax.swing.JButton();
        btn_remove_saleorder = new javax.swing.JButton();
        btn_modify_sale_order = new javax.swing.JButton();
        tf_entered_order_id = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 550));

        jPanel1.setBackground(new java.awt.Color(53, 79, 82));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 207, 149));

        jLabel1.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(53, 79, 82));
        jLabel1.setText("Manage ");

        jLabel2.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(53, 79, 82));
        jLabel2.setText("Sales Order");

        jLabel3.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(53, 79, 82));
        jLabel3.setText("Quotation");

        btn_create_new_order.setBackground(new java.awt.Color(53, 79, 82));
        btn_create_new_order.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn_create_new_order.setForeground(new java.awt.Color(255, 207, 149));
        btn_create_new_order.setText("Create New Order");
        btn_create_new_order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_create_new_orderActionPerformed(evt);
            }
        });

        btn_remove_saleorder.setBackground(new java.awt.Color(53, 79, 82));
        btn_remove_saleorder.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn_remove_saleorder.setForeground(new java.awt.Color(255, 207, 149));
        btn_remove_saleorder.setText("Remove");
        btn_remove_saleorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_remove_saleorderActionPerformed(evt);
            }
        });

        btn_modify_sale_order.setBackground(new java.awt.Color(53, 79, 82));
        btn_modify_sale_order.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn_modify_sale_order.setForeground(new java.awt.Color(255, 207, 149));
        btn_modify_sale_order.setText("Modify");
        btn_modify_sale_order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modify_sale_orderActionPerformed(evt);
            }
        });

        tf_entered_order_id.setBackground(new java.awt.Color(255, 255, 204));
        tf_entered_order_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_entered_order_idActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(53, 79, 82));
        jLabel4.setText("Enter Order ID");

        jButton1.setBackground(new java.awt.Color(53, 79, 82));
        jButton1.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 207, 149));
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel3))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tf_entered_order_id)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btn_modify_sale_order, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41)
                                .addComponent(btn_remove_saleorder, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel4)
                            .addComponent(btn_create_new_order, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(btn_create_new_order, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_entered_order_id, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_modify_sale_order, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_remove_saleorder, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 360, 500);

        jPanel3.setBackground(new java.awt.Color(53, 79, 82));

        jTable1.setBackground(new java.awt.Color(255, 207, 149));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "OrderID", "Customer"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(360, 0, 440, 500);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 335, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 195, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_create_new_orderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_create_new_orderActionPerformed
        CreateSalesOrderQuotation create_sales_quotation_frame = new CreateSalesOrderQuotation();
        create_sales_quotation_frame.setVisible(true);
        create_sales_quotation_frame.pack();
        create_sales_quotation_frame.setLocationRelativeTo(null);
        this.dispose();
        
    }//GEN-LAST:event_btn_create_new_orderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        SalespersonDashboard salesperson_frame = new SalespersonDashboard();
        salesperson_frame.setVisible(true);
        salesperson_frame.pack();
        salesperson_frame.setLocationRelativeTo(null);
        this.dispose();
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btn_remove_saleorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_remove_saleorderActionPerformed
        System.out.println("Btn remove debug line");
        
        String order_id = tf_entered_order_id.getText();
        
        ArrayList<SaleOrderQuotation> sales_order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        
        ArrayList<ApprovalReport> approval_report_list = readReportsFromCSV("ApprovalReportData.csv");
        
        deleteSaleOrderFromCSV(sales_order_list,order_id,"SaleOrderQuotationData.csv");
        
        deleteReportFromCSV(approval_report_list,order_id,"ApprovalReportData.csv");
        
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        tblModel.setRowCount(0); // Clear existing rows
        
        ArrayList<SaleOrderQuotation> new_sales_order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        
        for (SaleOrderQuotation order : new_sales_order_list) {
            
            String sale_order_id = order.getSale_order_ID();
            String customer_name = order.getCustomer_name();
            
            String data[] = {sale_order_id,customer_name};
            tblModel.addRow(data);
            
        }
    }//GEN-LAST:event_btn_remove_saleorderActionPerformed

    private void btn_modify_sale_orderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modify_sale_orderActionPerformed
        if(!tf_entered_order_id.getText().equals("")){
        
        ArrayList<SaleOrderQuotation> sales_order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        
        String sale_order_id = tf_entered_order_id.getText();
        
        SaleOrderQuotation selected_order = findSaleOrderByOrderID(sales_order_list,sale_order_id);
        
        SessionSalesOrder.setCurrentOrder(selected_order);
        
        ModifySaleOrderQuotation modify_order_frame = new ModifySaleOrderQuotation();
        modify_order_frame.setVisible(true);
        modify_order_frame.pack();
        modify_order_frame.setLocationRelativeTo(null);
        this.dispose();
        }
    }//GEN-LAST:event_btn_modify_sale_orderActionPerformed

    private void tf_entered_order_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_entered_order_idActionPerformed
    }//GEN-LAST:event_tf_entered_order_idActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageSaleOrderQuotationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageSaleOrderQuotationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageSaleOrderQuotationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageSaleOrderQuotationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageSaleOrderQuotationFrame().setVisible(true);
            }
        });
    }
    
    private void populateExistingTable() {
        // Method not yet made
        ArrayList<SaleOrderQuotation> sales_order_list = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        tblModel.setRowCount(0); // Clear existing rows
        
        for (SaleOrderQuotation order : sales_order_list) {
            
            String order_id = order.getSale_order_ID();
            String customer_name = order.getCustomer_name();
            
            String data[] = {order_id,customer_name};
            tblModel.addRow(data);
            
        }
        
    }
    
    public void deleteSaleOrderFromCSV(ArrayList<SaleOrderQuotation> sale_order_quotation_list, String order_ID, String csvFileName) {
    // Find the index of the report to be deleted in the list
        System.out.println("DeleteSaleOrder debug line");
    
    int index = -1;
    for (int i = 0; i < sale_order_quotation_list.size(); i++) {
        SaleOrderQuotation order = sale_order_quotation_list.get(i);
        if (order.getSale_order_ID().equals(order_ID)) {
            index = i;
            break;
        }
    }
    
    // Delete the report from the list if found
    if (index != -1) {
        sale_order_quotation_list.remove(index);
        
        // Write the updated list back to the CSV file
        writeSaleOrderListToCSV(sale_order_quotation_list, csvFileName);
        System.out.println("Record Removed");
    } else {
        System.out.println("Report not found in the list.");
    }
}
    
    public void deleteReportFromCSV(ArrayList<ApprovalReport> approval_report_list, String order_ID, String csvFileName) {
    // Find the index of the report to be deleted in the list
        System.out.println("Delete report debug line");
    
    int index = -1;
    for (int i = 0; i < approval_report_list.size(); i++) {
        ApprovalReport report = approval_report_list.get(i);
        if (report.getSaleOrderID().equals(order_ID)) {
            index = i;
            break;
        }
    }
    
    // Delete the report from the list if found
    if (index != -1) {
        approval_report_list.remove(index);
        
        // Write the updated list back to the CSV file
        writeApprovalReportListToCSV(approval_report_list, csvFileName);
        System.out.println("Record Removed");
    } else {
        System.out.println("Report not found in the list.");
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_create_new_order;
    private javax.swing.JButton btn_modify_sale_order;
    private javax.swing.JButton btn_remove_saleorder;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField tf_entered_order_id;
    // End of variables declaration//GEN-END:variables
}
