
package GUI.ManageSaleOrderQuotation;

import static InputOutput.CSVFileCreator.createCsvFile;
import static InputOutput.CSVDataReader.readFurnitureItemsFromCSV;
import static InputOutput.CSVWriter.writeApprovalReportToCSV;
import static InputOutput.CSVWriter.writeSaleOrderToCSV;
import SaleOrder.FurnitureItem;
import SaleOrder.SaleOrderQuotation;
import UserProfile.Session.SessionManager;
import UserProfile.User;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import javax.swing.table.DefaultTableModel;
import static searchAlgo.CSVSearch.findItemByFurnitureID;

public class CreateSalesOrderQuotation extends javax.swing.JFrame {
    
    private ArrayList<FurnitureItem> furniture_item_list = new ArrayList<FurnitureItem>();

    public CreateSalesOrderQuotation() {
        initComponents();
        populateExistingTable();
    }

    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        tf_entered_item_id = new javax.swing.JTextField();
        btn_addItem = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        tf_customer_address = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tf_customer_name = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tf_customer_email = new javax.swing.JTextField();
        btn_return = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_selected_item_list = new javax.swing.JTable();
        btn_remove_item = new javax.swing.JButton();
        tf_remove_item = new javax.swing.JTextField();
        btn_finish_sale_order = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(840, 600));

        jTabbedPane1.setBackground(new java.awt.Color(255, 207, 149));
        jTabbedPane1.setPreferredSize(new java.awt.Dimension(800, 600));

        jPanel1.setBackground(new java.awt.Color(53, 79, 82));
        jPanel1.setMinimumSize(new java.awt.Dimension(800, 500));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 600));
        jPanel1.setLayout(null);

        jPanel3.setBackground(new java.awt.Color(255, 207, 149));

        jLabel1.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(53, 79, 82));
        jLabel1.setText("Create Sale Order");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(267, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(259, 259, 259))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(17, 17, 17))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 820, 83);

        jTable1.setBackground(new java.awt.Color(53, 79, 82));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Furniture Name", "Furniture ID"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(330, 100, 470, 402);

        jLabel4.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 207, 149));
        jLabel4.setText("Enter Furniture ID");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(30, 370, 170, 24);

        tf_entered_item_id.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(tf_entered_item_id);
        tf_entered_item_id.setBounds(30, 400, 230, 30);

        btn_addItem.setBackground(new java.awt.Color(102, 204, 255));
        btn_addItem.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        btn_addItem.setForeground(new java.awt.Color(0, 0, 0));
        btn_addItem.setText("Add Item");
        btn_addItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addItemActionPerformed(evt);
            }
        });
        jPanel1.add(btn_addItem);
        btn_addItem.setBounds(30, 440, 160, 30);

        jPanel7.setBackground(new java.awt.Color(255, 207, 149));

        tf_customer_address.setBackground(new java.awt.Color(255, 255, 204));

        jLabel3.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(53, 79, 82));
        jLabel3.setText("Customer Address");

        jLabel2.setBackground(new java.awt.Color(255, 207, 149));
        jLabel2.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(53, 79, 82));
        jLabel2.setText("Customer Name");

        tf_customer_name.setBackground(new java.awt.Color(255, 255, 204));

        jLabel5.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(53, 79, 82));
        jLabel5.setText("Customer Email");

        tf_customer_email.setBackground(new java.awt.Color(255, 255, 204));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_customer_name, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_customer_address, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                    .addComponent(tf_customer_email))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_customer_name, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_customer_address, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_customer_email, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel7);
        jPanel7.setBounds(20, 100, 300, 260);

        btn_return.setBackground(new java.awt.Color(255, 207, 149));
        btn_return.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 12)); // NOI18N
        btn_return.setForeground(new java.awt.Color(53, 79, 82));
        btn_return.setText("Return");
        btn_return.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_returnActionPerformed(evt);
            }
        });
        jPanel1.add(btn_return);
        btn_return.setBounds(30, 490, 130, 30);

        jTabbedPane1.addTab("Create Sale Order", jPanel1);

        jPanel2.setBackground(new java.awt.Color(53, 79, 82));
        jPanel2.setLayout(null);

        jPanel4.setBackground(new java.awt.Color(255, 207, 149));

        jLabel6.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(53, 79, 82));
        jLabel6.setText("Sales Order Furniture Items");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(182, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(177, 177, 177))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel6)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel4);
        jPanel4.setBounds(0, 0, 820, 90);

        jTable_selected_item_list.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Item Name", "Item ID"
            }
        ));
        jScrollPane2.setViewportView(jTable_selected_item_list);

        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(320, 110, 452, 402);

        btn_remove_item.setBackground(new java.awt.Color(53, 79, 82));
        btn_remove_item.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 14)); // NOI18N
        btn_remove_item.setForeground(new java.awt.Color(255, 207, 149));
        btn_remove_item.setText("Remove");
        btn_remove_item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_remove_itemActionPerformed(evt);
            }
        });
        jPanel2.add(btn_remove_item);
        btn_remove_item.setBounds(80, 310, 140, 40);

        tf_remove_item.setBackground(new java.awt.Color(255, 255, 204));
        tf_remove_item.setFont(new java.awt.Font("Microsoft PhagsPa", 0, 14)); // NOI18N
        jPanel2.add(tf_remove_item);
        tf_remove_item.setBounds(30, 240, 240, 50);

        btn_finish_sale_order.setBackground(new java.awt.Color(102, 204, 255));
        btn_finish_sale_order.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 18)); // NOI18N
        btn_finish_sale_order.setForeground(new java.awt.Color(0, 0, 0));
        btn_finish_sale_order.setText("Finish Sale Order");
        btn_finish_sale_order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_finish_sale_orderActionPerformed(evt);
            }
        });
        jPanel2.add(btn_finish_sale_order);
        btn_finish_sale_order.setBounds(60, 420, 180, 50);

        jLabel8.setBackground(new java.awt.Color(255, 207, 149));
        jLabel8.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(53, 79, 82));
        jLabel8.setText("Enter Item ID");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(30, 200, 130, 24);

        jPanel5.setBackground(new java.awt.Color(255, 207, 149));
        jPanel5.setForeground(new java.awt.Color(255, 255, 204));

        jLabel7.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(53, 79, 82));
        jLabel7.setText("Remove Item");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel7)
                .addContainerGap(200, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel5);
        jPanel5.setBounds(20, 110, 280, 260);

        jTabbedPane1.addTab("View Item List", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 818, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 311, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 575, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 119, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_finish_sale_orderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_finish_sale_orderActionPerformed
        
        //retrieve personal data from session manager
        User currentProfileUser = SessionManager.getCurrentUser();
        //get current user's name
        String salesperson_name = currentProfileUser.getUsername();
        //create sale order Id
        String order_ID = generateSaleOrderID(salesperson_name);
        // get customer name
        String customer_username = tf_customer_name.getText();
        // get customer address
        String customer_address = tf_customer_address.getText();
        //get customer email
        String customer_email = tf_customer_email.getText();
        // get date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String date = dateFormat.format(new Date());
        
        //Create Sales Order Quotation 
        SaleOrderQuotation order_quotation = new SaleOrderQuotation(salesperson_name, order_ID, customer_username, customer_address, customer_email, date, furniture_item_list);
        // Put order quotation object to csv file
        createCsvFile("SaleOrderQuotationData.csv");
        writeSaleOrderToCSV(order_quotation,"SaleOrderQuotationData.csv");
        //write approval to a csv file
        createCsvFile("ApprovalReportData.csv");
        writeApprovalReportToCSV(order_quotation.getApprovalReport(),"ApprovalReportData.csv");
        
        //return to menu
        ManageSaleOrderQuotationFrame manage_sale_quotation_frame = new ManageSaleOrderQuotationFrame();
        manage_sale_quotation_frame.setVisible(true);
        manage_sale_quotation_frame.pack();
        manage_sale_quotation_frame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btn_finish_sale_orderActionPerformed

    private void btn_returnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_returnActionPerformed
        ManageSaleOrderQuotationFrame manage_sale_quotation_frame = new ManageSaleOrderQuotationFrame();
        manage_sale_quotation_frame.setVisible(true);
        manage_sale_quotation_frame.pack();
        manage_sale_quotation_frame.setLocationRelativeTo(null);
        this.dispose();
        
    }//GEN-LAST:event_btn_returnActionPerformed

    private void btn_addItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addItemActionPerformed

        // save dataset to arraylist
        ArrayList<FurnitureItem> csv_item_list = readFurnitureItemsFromCSV("dataset.csv");

        // get item id from text field
        String entered_furniture_id = tf_entered_item_id.getText();

        // search and get the item that matches with entered item id
        FurnitureItem selected_item = findItemByFurnitureID(csv_item_list, entered_furniture_id);

        // check if the selected item is not null before proceeding
        if (selected_item != null) {
            // add matched item to the global arraylist furniture itemlist
            furniture_item_list.add(selected_item);

            // set table
            DefaultTableModel tblModel2 = (DefaultTableModel) jTable_selected_item_list.getModel();
            tblModel2.setRowCount(0);

            // fill table with data
            for (FurnitureItem furniture_item : furniture_item_list) {
                String item_name = furniture_item.getFurnitureName();
                String item_id = furniture_item.getFurniture_ID();

                String data[] = {item_name, item_id};
                tblModel2.addRow(data);
                
                tf_entered_item_id.setText("");  // Set the text field to an empty string
            }
        } else {
            System.out.println("Selected item is null or not found.");
        }
    }//GEN-LAST:event_btn_addItemActionPerformed

    private void btn_remove_itemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_remove_itemActionPerformed
        String typed_item_to_remove = tf_remove_item.getText();
        String item_to_remove = "\"" + typed_item_to_remove + "\"";
        
        if(item_to_remove != null){
            for (int i = 0; i < furniture_item_list.size(); i++) {
            FurnitureItem furniture_item = furniture_item_list.get(i);
            if (item_to_remove.equals(furniture_item.getFurniture_ID())) {
                // Remove the item from the list
                furniture_item_list.remove(i);
                System.out.println("Item Removed");
                // Remove the corresponding row from the table
                DefaultTableModel tblModel2 = (DefaultTableModel) jTable_selected_item_list.getModel();
                tblModel2.removeRow(i);

                break; // Assuming there's only one matching item_id
                }
            }
        }
    }//GEN-LAST:event_btn_remove_itemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CreateSalesOrderQuotation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CreateSalesOrderQuotation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CreateSalesOrderQuotation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CreateSalesOrderQuotation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CreateSalesOrderQuotation().setVisible(true);
            }
        });
    }
    
    private void populateExistingTable() {
        
        ArrayList<FurnitureItem> furniture_item_list = readFurnitureItemsFromCSV("dataset.csv");
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        tblModel.setRowCount(0); // Clear existing rows
        
        for (FurnitureItem item : furniture_item_list) {
            
            String item_name = item.getFurnitureName();
            String item_id = item.getFurniture_ID();
            
            String data[] = {item_name,item_id};
            tblModel.addRow(data);
            
        }
        
    }
    
    
    private String generateSaleOrderID(String salespersonUsername) {
        // Get the first three letters of the salesperson's username
        String usernamePrefix = salespersonUsername.substring(0, Math.min(salespersonUsername.length(), 3));

        // Get current timestamp
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = dateFormat.format(new Date());

        // Generate a random number (you can customize the range as needed)
        Random random = new Random();
        int randomNumber = random.nextInt(10000); // Example: 4-digit random number

        // Combine username prefix, timestamp, and random number to create a unique ID
        return usernamePrefix + timestamp + String.format("%04d", randomNumber);
    }
    

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_addItem;
    private javax.swing.JButton btn_finish_sale_order;
    private javax.swing.JButton btn_remove_item;
    private javax.swing.JButton btn_return;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable_selected_item_list;
    private javax.swing.JTextField tf_customer_address;
    private javax.swing.JTextField tf_customer_email;
    private javax.swing.JTextField tf_customer_name;
    private javax.swing.JTextField tf_entered_item_id;
    private javax.swing.JTextField tf_remove_item;
    // End of variables declaration//GEN-END:variables
}
