
package GUI.ManageSaleOrderQuotation;

import GUI.ProcessSaleOrder.ProcessSaleOrder;
import static InputOutput.CSVDataReader.readFurnitureItemsFromCSV;
import static InputOutput.CSVDataReader.readSaleOrderQuotationFromCSV;
import SaleOrder.FurnitureItem;
import SaleOrder.SaleOrderQuotation;
import UserProfile.Session.SessionManager;
import UserProfile.Session.SessionSalesOrder;
import UserProfile.User;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import static searchAlgo.CSVSearch.findItemByFurnitureID;

public class ModifySaleOrderQuotation extends javax.swing.JFrame {
    
    private ArrayList<FurnitureItem> furniture_item_list = new ArrayList<FurnitureItem>();
    
    /**
     * Creates new form ModifySaleOrderQuotation
     */
    public ModifySaleOrderQuotation() {
        
        initComponents();
        populateExistingTable();
    }

    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        tf_entered_item_id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btn_return_to_menu = new javax.swing.JButton();
        btn_add_item = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_selected_item_list = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        tf_remove_item = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btn_save_changes = new javax.swing.JButton();
        btn_remove_item = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 600));
        getContentPane().setLayout(null);

        jTabbedPane1.setBackground(new java.awt.Color(255, 207, 149));
        jTabbedPane1.setPreferredSize(new java.awt.Dimension(800, 600));

        jPanel1.setBackground(new java.awt.Color(53, 79, 82));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 650));

        jPanel3.setBackground(new java.awt.Color(255, 207, 149));

        jLabel1.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(53, 79, 82));
        jLabel1.setText("Modify Sale Order");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(231, 231, 231)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jTable1.setBackground(new java.awt.Color(53, 79, 82));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Furniture Name", "Furniture ID"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 207, 149));
        jLabel2.setText("Add Furniture to List");

        tf_entered_item_id.setBackground(new java.awt.Color(255, 255, 204));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 207, 149));
        jLabel3.setText("Enter Furniture ID");

        btn_return_to_menu.setBackground(new java.awt.Color(255, 207, 149));
        btn_return_to_menu.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_return_to_menu.setForeground(new java.awt.Color(53, 79, 82));
        btn_return_to_menu.setText("Back");
        btn_return_to_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_return_to_menuActionPerformed(evt);
            }
        });

        btn_add_item.setBackground(new java.awt.Color(255, 207, 149));
        btn_add_item.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_add_item.setForeground(new java.awt.Color(53, 79, 82));
        btn_add_item.setText("Add Item");
        btn_add_item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_itemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(btn_return_to_menu, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_entered_item_id, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(btn_add_item, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addComponent(jLabel2)
                        .addGap(37, 37, 37)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tf_entered_item_id, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_add_item, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_return_to_menu, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 57, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Add Items", jPanel1);

        jPanel2.setBackground(new java.awt.Color(53, 79, 82));
        jPanel2.setPreferredSize(new java.awt.Dimension(800, 600));

        jPanel4.setBackground(new java.awt.Color(255, 207, 149));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(53, 79, 82));
        jLabel4.setText("Furniture Item List");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(229, 229, 229)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel4)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jTable_selected_item_list.setBackground(new java.awt.Color(53, 79, 82));
        jTable_selected_item_list.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Item Name", "Item ID"
            }
        ));
        jScrollPane2.setViewportView(jTable_selected_item_list);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 207, 149));
        jLabel5.setText("Remove Item");

        tf_remove_item.setBackground(new java.awt.Color(255, 255, 204));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 207, 149));
        jLabel6.setText("Enter Item ID");

        btn_save_changes.setBackground(new java.awt.Color(255, 207, 149));
        btn_save_changes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_save_changes.setForeground(new java.awt.Color(53, 79, 82));
        btn_save_changes.setText("Save Changes");
        btn_save_changes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_save_changesActionPerformed(evt);
            }
        });

        btn_remove_item.setBackground(new java.awt.Color(255, 207, 149));
        btn_remove_item.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_remove_item.setForeground(new java.awt.Color(53, 79, 82));
        btn_remove_item.setText("Remove item");
        btn_remove_item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_remove_itemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_remove_item, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addComponent(jLabel5))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_remove_item, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_save_changes, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE))))
                .addContainerGap(75, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 45, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(jLabel5)
                        .addGap(40, 40, 40)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(tf_remove_item, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_remove_item, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_save_changes, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(95, 95, 95))))
        );

        jTabbedPane1.addTab("Remove Items", jPanel2);

        getContentPane().add(jTabbedPane1);
        jTabbedPane1.setBounds(0, 0, 800, 600);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_add_itemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_itemActionPerformed
        // save dataset to arraylist
        ArrayList<FurnitureItem> csv_item_list = readFurnitureItemsFromCSV("dataset.csv");

        // get item id from text field
        String entered_furniture_id = tf_entered_item_id.getText();

        // search and get the item that matches with entered item id
        FurnitureItem selected_item = findItemByFurnitureID(csv_item_list, entered_furniture_id);

        // check if the selected item is not null before proceeding
        if (selected_item != null) {
            // add matched item to the global arraylist furniture itemlist
            furniture_item_list.add(selected_item);

            // set table
            DefaultTableModel tblModel2 = (DefaultTableModel) jTable_selected_item_list.getModel();
            tblModel2.setRowCount(0);

            // fill table with data
            for (FurnitureItem furniture_item : furniture_item_list) {
                String item_name = furniture_item.getFurnitureName();
                String item_id = furniture_item.getFurniture_ID();

                String data[] = {item_name, item_id};
                tblModel2.addRow(data);
                
                tf_entered_item_id.setText("");  // Set the text field to an empty string
            }
        } else {
            System.out.println("Selected item is null or not found.");
        }
        
    }//GEN-LAST:event_btn_add_itemActionPerformed

    private void btn_remove_itemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_remove_itemActionPerformed
        String typed_item_to_remove = tf_remove_item.getText();
        String item_to_remove = "\"" + typed_item_to_remove + "\"";
        
        if(item_to_remove != null){
            for (int i = 0; i < furniture_item_list.size(); i++) {
            FurnitureItem furniture_item = furniture_item_list.get(i);
            if (item_to_remove.equals(furniture_item.getFurniture_ID())) {
                // Remove the item from the list
                furniture_item_list.remove(i);
                System.out.println("Item Removed");
                
                DefaultTableModel tblModel2 = (DefaultTableModel) jTable_selected_item_list.getModel();
                tblModel2.removeRow(i);

                break; 
                }
            }
        }
        
    }//GEN-LAST:event_btn_remove_itemActionPerformed

    private void btn_save_changesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_save_changesActionPerformed
        SaleOrderQuotation current_sale_order = SessionSalesOrder.getCurrentOrder();
        
        updateItemListInCSV(furniture_item_list,current_sale_order);
        
        System.out.println("Finish");
        
        User current_user = SessionManager.getCurrentUser();
        
        if(current_user.getRole().equals("Salesperson")){
            ManageSaleOrderQuotationFrame manage_order_frame = new ManageSaleOrderQuotationFrame();
            manage_order_frame.setVisible(true);
            manage_order_frame.pack();
            manage_order_frame.setLocationRelativeTo(null);
            this.dispose();
        }else if(current_user.getRole().equals("Officer")){
            ProcessSaleOrder process_order_frame = new ProcessSaleOrder();
            process_order_frame.setVisible(true);
            process_order_frame.pack();
            process_order_frame.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_btn_save_changesActionPerformed

    private void btn_return_to_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_return_to_menuActionPerformed
        User current_user = SessionManager.getCurrentUser();
        
        if(current_user.getRole().equals("Salesperson")){
            ManageSaleOrderQuotationFrame manage_order_frame = new ManageSaleOrderQuotationFrame();
            manage_order_frame.setVisible(true);
            manage_order_frame.pack();
            manage_order_frame.setLocationRelativeTo(null);
            this.dispose();
        }else if(current_user.getRole().equals("Officer")){
            ProcessSaleOrder process_order_frame = new ProcessSaleOrder();
            process_order_frame.setVisible(true);
            process_order_frame.pack();
            process_order_frame.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_btn_return_to_menuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModifySaleOrderQuotation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModifySaleOrderQuotation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModifySaleOrderQuotation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModifySaleOrderQuotation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModifySaleOrderQuotation().setVisible(true);
            }
        });
    }
    
    private void populateExistingTable() {
        ArrayList<FurnitureItem> furniture_item_list = readFurnitureItemsFromCSV("dataset.csv");
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        tblModel.setRowCount(0); // Clear existing rows
        
        for (FurnitureItem item : furniture_item_list) {
            
            String item_name = item.getFurnitureName();
            String item_id = item.getFurniture_ID();
            
            String data[] = {item_name,item_id};
            tblModel.addRow(data);
        }
    }
    
    private boolean updateItemListInCSV(ArrayList<FurnitureItem> furniture_item_list, SaleOrderQuotation modified_sale_order) {
    ArrayList<SaleOrderQuotation> csvOrders = readSaleOrderQuotationFromCSV("SaleOrderQuotationData.csv");

    // Find the order in the list
    int index = -1;
    for (int i = 0; i < csvOrders.size(); i++) {
        if (csvOrders.get(i).getSale_order_ID().equals(modified_sale_order.getSale_order_ID())) {
            index = i;
            break;
        }
    }

    // Update the order if found
    if (index != -1) {
        SaleOrderQuotation order = csvOrders.get(index);
        
        // Replace the item list with the new list
        order.setItem_list(furniture_item_list);
        
        csvOrders.set(index, order);

        // Write the updated list back to the CSV file
        writeOrdersToCSV("SaleOrderQuotationData.csv", csvOrders);

        return true; // Return true to indicate successful update
    } else {
        // Handle the case where the order is not found in the CSV
        System.out.println("Order not found in CSV");
        return false;
    }
}

    
    /*private void writeOrdersToCSV(String filename, ArrayList<SaleOrderQuotation> orders) {
    try (FileWriter csvWriter = new FileWriter(filename)) {
        for (SaleOrderQuotation order : orders) {
            csvWriter.append(order.getSalesperson_username())
                    .append(",")
                    .append(order.getSale_order_ID())
                    .append(",")
                    .append(order.getCustomer_name())
                    .append(",")
                    .append(order.getCustomer_address())
                    .append(",")
                    .append(order.getCustomer_email())
                    .append(",")
                    .append(order.getCreated_date());

            // Append items in the order
            ArrayList<FurnitureItem> itemList = order.getItem_list();
            int itemCount = itemList.size();
            for (int i = 0; i < itemCount; i++) {
                FurnitureItem item = itemList.get(i);
                    csvWriter.append(item.getFurniture_ID());
                // Append comma if it's not the last item
                if (i < itemCount - 1) {
                    csvWriter.append(",");
                }
            }
            csvWriter.append("\n"); // Add a new line for the next order
        }
        csvWriter.flush();
    } catch (IOException ex) {
        Logger.getLogger(ModifySaleOrderQuotation.class.getName()).log(Level.SEVERE, null, ex);
        // Handle IOException more appropriately, like logging or displaying an error message.
    }
}*/
    
    private void writeOrdersToCSV(String filename, ArrayList<SaleOrderQuotation> orders) {
    try (FileWriter csvWriter = new FileWriter(filename)) {
        for (SaleOrderQuotation order : orders) {
            csvWriter.append(order.getSalesperson_username())
                    .append(",")
                    .append(order.getSale_order_ID())
                    .append(",")
                    .append(order.getCustomer_name())
                    .append(",")
                    .append(order.getCustomer_address())
                    .append(",")
                    .append(order.getCustomer_email())
                    .append(",")
                    .append(order.getCreated_date());

            // Append items in the order
            ArrayList<FurnitureItem> itemList = order.getItem_list();
            int itemCount = itemList.size();
            if (itemCount > 0) {
                csvWriter.append(",");
                csvWriter.append(itemList.get(0).getFurniture_ID()); // Append the first item
                for (int i = 1; i < itemCount; i++) {
                    csvWriter.append(",").append(itemList.get(i).getFurniture_ID());
                }
            }

            csvWriter.append("\n"); // Add a new line for the next order
        }
        csvWriter.flush();
    } catch (IOException ex) {
        Logger.getLogger(ModifySaleOrderQuotation.class.getName()).log(Level.SEVERE, null, ex);
        // Handle IOException more appropriately, like logging or displaying an error message.
    }
}




    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add_item;
    private javax.swing.JButton btn_remove_item;
    private javax.swing.JButton btn_return_to_menu;
    private javax.swing.JButton btn_save_changes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable_selected_item_list;
    private javax.swing.JTextField tf_entered_item_id;
    private javax.swing.JTextField tf_remove_item;
    // End of variables declaration//GEN-END:variables
}
