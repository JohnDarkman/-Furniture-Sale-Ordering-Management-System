package GUI;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.util.ArrayList;

import static InputOutput.CSVDataReader.readUsersFromCSV;
import static InputOutput.CSVFileCreator.createCsvFile;
import static InputOutput.CSVWriter.writeUserToCSV;
import UserProfile.Administrator;
import UserProfile.Officer;
import UserProfile.Salesperson;
import UserProfile.User;
import UserProfile.Session.SessionManager;
import static Validation.EmailValidation.isValidEmail;
import static Validation.LoginValidation.validateLogin;
import static searchAlgo.CSVSearch.findUserByEmail;

import GUI.Dashboard.AdministratorDashboard;
import GUI.Dashboard.OfficerDashboard;
import GUI.Dashboard.SalespersonDashboard;

public class AuthPanel extends JPanel {
    boolean isLogin = true;
    JFrame parent;

    // LOGIN
    JPanel loginCard = new JPanel(new BorderLayout());

    JPanel leftPanelLogin = new JPanel(new BorderLayout());
    JPanel rightPanelLogin = new JPanel();
    JPanel logoLoginPanel = new JPanel();

    JLabel leftWelcomeLabel = new JLabel("Welcome Back!");
    JLabel leftIllustrationLabel = new JLabel();
    JLabel leftDummyLoginLabel = new JLabel("English United Kingdom");
    JLabel logoLoginLabel = new JLabel();
    JLabel signInLabel = new JLabel("Sign In");

    JLabel emailLoginLabel = new JLabel("Email");
    JLabel passwordLoginLabel = new JLabel("Password");

    JTextField emailLoginTextField = new JTextField("craftedcomfort@gmail.com");
    JPasswordField passwordLoginTextField = new JPasswordField("*******");

    // REGISTER
    JPanel registerCard = new JPanel(new BorderLayout());
    JPanel leftPanelRegister = new JPanel(new BorderLayout());
    JPanel leftPanelGridBagRegister = new JPanel(new GridBagLayout());
    JPanel rightPanelRegister = new JPanel();
    JPanel logoRegisterPanel = new JPanel();

    JLabel signUpLabel = new JLabel("Register Now!");
    JLabel leftStartedLabel = new JLabel("Let's Get Started!");
    JLabel leftDummyRegisterLabel = new JLabel("English United Kingdom");
    JLabel logoRegisterLabel = new JLabel();

    JLabel firstnameRegisterLabel = new JLabel("First Name");
    JLabel lastnameRegisterLabel = new JLabel("Last Name");
    JLabel roleRegisterLabel = new JLabel("Role");
    JLabel emailRegisterLabel = new JLabel("Email");
    JLabel passwordRegisterLabel = new JLabel("Password");
    JLabel passwordConfirmRegisterLabel = new JLabel("Password Confirm");

    JTextField firstnameRegisterTextField = new JTextField("Crafted");
    JTextField lastnameRegisterTextField = new JTextField("Comfort");
    JTextField emailRegisterTextField = new JTextField("craftedcomfort@gmail.com");
    JPasswordField passwordRegisterTextField = new JPasswordField("*******");
    JPasswordField passwordConfirmRegisterTextField = new JPasswordField("*******");
    @SuppressWarnings("rawtypes")
    JComboBox roleRegisterComboBox = new JComboBox<>(new String[] { "Administrator", "Officer", "Salesperson" });


    public AuthPanel(JFrame parent) {
        this.parent = parent;
        add(loginCard, BorderLayout.CENTER);
        loginCard.add(leftPanelLogin, BorderLayout.WEST);
        loginCard.add(rightPanelLogin, BorderLayout.EAST);
        registerCard.add(leftPanelRegister, BorderLayout.WEST);
        registerCard.add(rightPanelRegister, BorderLayout.EAST);

        loginCard.setSize(656, 448);
        loginCard.setBorder(new EmptyBorder(16,16,16,16));
        loginCard.setBackground(new Color(221,141,44,255));

        registerCard.setSize(656, 448);
        registerCard.setBorder(new EmptyBorder(16,16,16,16));
        registerCard.setBackground(new Color(221,141,44,255));

        setupLabel(leftWelcomeLabel, 24);
        setupLabel(leftStartedLabel, 24);
        setupLabel(signInLabel, 24);
        setupLabel(signUpLabel, 24);

        leftWelcomeLabel.setBorder(new EmptyBorder(16,16,0,0));
        leftStartedLabel.setBorder(new EmptyBorder(16,16,90,135));
        leftDummyLoginLabel.setBorder(new EmptyBorder(0,16,16,0));
        leftDummyRegisterLabel.setBorder(new EmptyBorder(90,16,16,0));
        signInLabel.setBorder(new EmptyBorder(0,0,0,226));
        signUpLabel.setBorder(new EmptyBorder(0,0,0,196));

        leftPanelLoginSetup();
        rightPanelLoginSetup();
        leftPanelRegisterSetup();
        rightPanelRegisterSetup();
    }

    private void setupLabel(JLabel label, int size) {
        label.setFont(new Font("Serif", Font.PLAIN, size));
    }

    private void leftPanelLoginSetup() {
        leftPanelLogin.setBackground(new Color(236,173,98,255));

        leftIllustrationLabel.setSize(360, 360);
        scaleImage(new ImageIcon("./asset/sofa.png"), leftIllustrationLabel);

        leftPanelLogin.add(leftWelcomeLabel, BorderLayout.NORTH);
        leftPanelLogin.add(leftIllustrationLabel, BorderLayout.CENTER);
        leftPanelLogin.add(leftDummyLoginLabel, BorderLayout.SOUTH);
    }

    private void leftPanelRegisterSetup() {
        // leftPanelRegister.setPreferredSize(new Dimension(350, 448));
        leftPanelRegister.setBackground(new Color(236,173,98,255));
        leftPanelGridBagRegister.setBackground(new Color(0, 0, 0, 0));
        leftPanelRegister.add(leftStartedLabel, BorderLayout.NORTH);
        leftPanelRegister.add(leftPanelGridBagRegister, BorderLayout.CENTER);
        leftPanelRegister.add(leftDummyRegisterLabel, BorderLayout.SOUTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Adjust spacing as needed
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        leftPanelGridBagRegister.add(firstnameRegisterLabel, gbc);

        gbc.gridy++;
        leftPanelGridBagRegister.add(firstnameRegisterTextField, gbc);

        gbc.gridy++;
        leftPanelGridBagRegister.add(lastnameRegisterLabel, gbc);

        gbc.gridy++;
        leftPanelGridBagRegister.add(lastnameRegisterTextField, gbc);

        gbc.gridy++;
        leftPanelGridBagRegister.add(roleRegisterLabel, gbc);

        gbc.gridy++;
        leftPanelGridBagRegister.add(roleRegisterComboBox, gbc);
        // String role = (String) user_comboBox.getSelectedItem();
    }

    private void rightPanelLoginSetup() {
        rightPanelLogin.add(logoLoginPanel);
        rightPanelLogin.setLayout(new GridBagLayout());
        rightPanelLogin.setBackground(new Color(255,207,149,90));

        logoLoginPanel.add(logoLoginLabel);
        logoLoginPanel.setBackground(new Color(0,0,0,0));
        logoLoginPanel.setSize(80, 80);
        scaleImage(new ImageIcon("./asset/logo.png"), logoLoginLabel, 75, 75);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Adjust spacing as needed
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        rightPanelLogin.add(logoLoginPanel, gbc);
    
        gbc.gridy++;
        rightPanelLogin.add(signInLabel, gbc);
    
        gbc.gridy++;
        rightPanelLogin.add(emailLoginLabel, gbc);
    
        gbc.gridy++;
        rightPanelLogin.add(emailLoginTextField, gbc);
    
        gbc.gridy++;
        rightPanelLogin.add(passwordLoginLabel, gbc);
    
        gbc.gridy++;
        rightPanelLogin.add(passwordLoginTextField, gbc);
    
        gbc.gridy++;
        JButton signInButton = new JButton("Sign In");
        rightPanelLogin.add(signInButton, gbc);
        signInButton.addActionListener(e -> {
            System.out.println("SIGN IN");
            login();
        });
    
        gbc.gridy++;
        JLabel additionalLabel = new JLabel("Don't Have an Account?");
        rightPanelLogin.add(additionalLabel, gbc);
    
        gbc.gridy++;
        JButton additionalButton = new JButton("Register Now!");
        rightPanelLogin.add(additionalButton, gbc);
        additionalButton.addActionListener(e -> {
            this.switchPanel();
        });
    }

    private void rightPanelRegisterSetup() {
        // rightPanelRegister.setPreferredSize(new Dimension(306, 448));
        rightPanelRegister.add(logoRegisterPanel);
        rightPanelRegister.setLayout(new GridBagLayout());
        rightPanelRegister.setBackground(new Color(255,207,149,90));

        logoRegisterPanel.add(logoRegisterLabel);
        logoRegisterPanel.setBackground(new Color(0,0,0,0));
        logoRegisterPanel.setSize(80, 80);
        scaleImage(new ImageIcon("./asset/logo.png"), logoRegisterLabel, 75, 75);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Adjust spacing as needed
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        rightPanelRegister.add(logoRegisterPanel, gbc);
    
        gbc.gridy++;
        rightPanelRegister.add(signUpLabel, gbc);

        gbc.gridy++;
        rightPanelRegister.add(emailRegisterLabel, gbc);
    
        gbc.gridy++;
        rightPanelRegister.add(emailRegisterTextField, gbc);
    
        gbc.gridy++;
        rightPanelRegister.add(passwordRegisterLabel, gbc);
    
        gbc.gridy++;
        rightPanelRegister.add(passwordRegisterTextField, gbc);
    
        gbc.gridy++;
        rightPanelRegister.add(passwordConfirmRegisterLabel, gbc);
    
        gbc.gridy++;
        rightPanelRegister.add(passwordConfirmRegisterTextField, gbc);
    
        gbc.gridy++;
        JButton signInButton = new JButton("Register");
        rightPanelRegister.add(signInButton, gbc);
        signInButton.addActionListener(e -> {
            System.out.println("REGISTER");
            register();
        });
    
        gbc.gridy++;
        JLabel additionalLabel = new JLabel("Already Have an Account?");
        rightPanelRegister.add(additionalLabel, gbc);
    
        gbc.gridy++;
        JButton additionalButton = new JButton("Sign In!");
        rightPanelRegister.add(additionalButton, gbc);
        additionalButton.addActionListener(e -> {
            this.switchPanel();
        });
    }

    private void scaleImage(ImageIcon icon, JLabel label) {
        // setup jLabel image
        Image img = icon.getImage();
        Image imgscale = img.getScaledInstance(leftIllustrationLabel.getWidth(), leftIllustrationLabel.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgscale);
        label.setIcon(scaledIcon);
    }

    private void scaleImage(ImageIcon icon, JLabel label, int width, int height) {
        // setup jLabel image
        Image img = icon.getImage();
        Image imgscale = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgscale);
        label.setIcon(scaledIcon);
    }

    private void switchPanel() {
        remove((isLogin) ? loginCard : registerCard);
        add((!isLogin) ? loginCard : registerCard);
        revalidate();
        repaint();
        isLogin = !isLogin;
    }

    private void login() {
                
        ArrayList<User> login_user = readUsersFromCSV("Users.csv");
        String email_login = emailLoginTextField.getText();
        @SuppressWarnings("deprecation")
        String password_login = passwordLoginTextField.getText();

        boolean isValidLogin = validateLogin(login_user, email_login, password_login);

        if (isValidLogin) {
            // Find the user to get the role
            User loggedInUser = findUserByEmail (login_user, email_login);
            
            // session manager to show which user is currently signed in
            SessionManager.setCurrentUser(loggedInUser);

            if (loggedInUser != null) {
                // Check the user's role and redirect accordingly
                if (loggedInUser.getRole().equalsIgnoreCase("Administrator")) {
                    // Redirect to the admin dashboard
                    System.out.println("Login Admin Dashboard.");
                    //admin dashboard code
                    AdministratorDashboard admin_dashboard_frame = new AdministratorDashboard();
                    admin_dashboard_frame.setVisible(true);
                    admin_dashboard_frame.pack();
                    admin_dashboard_frame.setLocationRelativeTo(null);
                    parent.dispose();
                    
                } else if (loggedInUser.getRole().equalsIgnoreCase("Officer")) {
                    // Redirect to the officer dashboard
                    System.out.println("Login Officer Dashboard.");
                    // officer dashboard code
                    OfficerDashboard officer_dashboard_frame = new OfficerDashboard();
                    officer_dashboard_frame.setVisible(true);
                    officer_dashboard_frame.pack();
                    officer_dashboard_frame.setLocationRelativeTo(null);
                    parent.dispose();
                    
                } else if(loggedInUser.getRole().equalsIgnoreCase("Salesperson")) {
                    // Handle other roles if needed
                    System.out.println("Login Salesperson dashboard.");
                    // Add code to open a default dashboard here
                    SalespersonDashboard salesperson_dashboard_frame = new SalespersonDashboard();
                    salesperson_dashboard_frame.setVisible(true);
                    salesperson_dashboard_frame.pack();
                    salesperson_dashboard_frame.setLocationRelativeTo(null);
                    parent.dispose();
                }
            }
        } else {
            // Login failed, display an error message or take appropriate action
            System.out.println("Login failed. Invalid email or password.");
            JOptionPane.showMessageDialog(this,"Login failed, Invalid email or password");
        }
    }


    private void register() {
        String first_name = firstnameRegisterTextField.getText();
        String last_name = lastnameRegisterTextField.getText();
        String username = first_name + " " + last_name ;
        String email = emailRegisterTextField.getText();
        @SuppressWarnings("deprecation")
        String password = passwordRegisterTextField.getText();
        @SuppressWarnings("deprecation")
        String confirmed_password = passwordConfirmRegisterTextField.getText();
        
        String role = (String) roleRegisterComboBox.getSelectedItem();
        
        switch(role){
            case "Administrator":
                if(isValidEmail(email) && confirmed_password.equals(password)){
                    Administrator admin = new Administrator(username,email,password,role);
                    createCsvFile("Users.csv");
                    writeUserToCSV(admin,"Users.csv");
                    
                    SessionManager.setCurrentUser(admin);
                    
                    AdministratorDashboard admin_dashboard_frame = new AdministratorDashboard();
                    admin_dashboard_frame.setVisible(true);
                    admin_dashboard_frame.pack();
                    admin_dashboard_frame.setLocationRelativeTo(null);
                    parent.dispose();
                }
                break;
                
            case "Officer":
                if(isValidEmail(email) && confirmed_password.equals(password)){
                    Officer officer = new Officer(username,email,password,role);
                    createCsvFile("Users.csv");
                    writeUserToCSV(officer,"Users.csv");
                    
                    SessionManager.setCurrentUser(officer);
                    
                    OfficerDashboard officer_dashboard_frame = new OfficerDashboard();
                    officer_dashboard_frame.setVisible(true);
                    officer_dashboard_frame.pack();
                    officer_dashboard_frame.setLocationRelativeTo(null);
                    parent.dispose();
                }
                break;
                
            case "Salesperson":
                if(isValidEmail(email) && confirmed_password.equals(password)){
                    Salesperson sp = new Salesperson(username,email,password,role);
                    createCsvFile("Users.csv");
                    writeUserToCSV(sp,"Users.csv");
                    
                    SessionManager.setCurrentUser(sp);
                    
                    SalespersonDashboard salesperson_dashboard_frame = new SalespersonDashboard();
                    salesperson_dashboard_frame.setVisible(true);
                    salesperson_dashboard_frame.pack();
                    salesperson_dashboard_frame.setLocationRelativeTo(null);
                    parent.dispose();
                }
                break;
                
        }
    }
}
