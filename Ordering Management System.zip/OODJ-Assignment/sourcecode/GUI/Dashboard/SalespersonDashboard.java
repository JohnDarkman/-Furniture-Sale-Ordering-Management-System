package GUI.Dashboard;

import GUI.ManageSaleOrderQuotation.ManageSaleOrderQuotationFrame;
import GUI.Profile.ManagePersonalProfile;
import GUI.ViewPersonalSalesOrder.FindPersonalSalesOrder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import GUI.MainWindow;

public class SalespersonDashboard extends javax.swing.JFrame {
    private javax.swing.JButton MPP;
    private javax.swing.JButton btn_find_personal_sales;
    private javax.swing.JButton btn_manage_salesquotation;
    private javax.swing.JButton btn_return;

    public SalespersonDashboard() {
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(MainWindow.WIDTH, MainWindow.HEIGHT));
        setResizable(false);

        JPanel jPanel1 = new JPanel();
        jPanel1.setLayout(new BorderLayout());
        jPanel1.setBackground(new Color(221,141,44,255));

        JPanel jPanel2 = new JPanel();
        jPanel2.setBackground(new Color(214, 140, 51));
        JLabel jLabel1 = new JLabel("Salesperson Dashboard");
        jLabel1.setFont(new Font("Microsoft PhagsPa", Font.BOLD, 48));
        jLabel1.setForeground(Color.WHITE);
        jPanel2.add(jLabel1);

        jPanel1.add(jPanel2, BorderLayout.NORTH);

        JPanel jPanel3 = new JPanel(new GridBagLayout());
        jPanel3.setBackground(Color.WHITE);

        MPP = createButton("Manage Personal profile", this::MPPActionPerformed);
        btn_manage_salesquotation = createButton("Manage Sale Order Quotation", this::btn_manage_salesquotationActionPerformed);
        btn_find_personal_sales = createButton("Review Personal Sale Orders", this::btn_find_personal_salesActionPerformed);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        addComponent(jPanel3, MPP, gbc, 0, 0, 120, 120);
        addComponent(jPanel3, btn_manage_salesquotation, gbc, 1, 0, 130, 120);
        addComponent(jPanel3, btn_find_personal_sales, gbc, 2, 0, 130, 120);

        addComponent(jPanel3, new JLabel("Manage Personal profile"), gbc, 0, 1, 140, 16);
        addComponent(jPanel3, new JLabel("Manage Sale Order Quotation"), gbc, 1, 1, 170, 20);
        addComponent(jPanel3, new JLabel("Review Personal Sale Orders"), gbc, 2, 1, 180, 20);

        btn_return = createButton("Back to Login", this::btn_returnActionPerformed);
        addComponent(jPanel3, btn_return, gbc, 0, 2, 130, 25);

        jPanel1.add(jPanel3, BorderLayout.CENTER);

        getContentPane().add(jPanel1);
        pack();
        setLocationRelativeTo(null);
    }

    private void addComponent(JPanel panel, JComponent component, GridBagConstraints gbc, int gridx, int gridy, int width, int height) {
        gbc.gridx = gridx;
        gbc.gridy = gridy;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(component, gbc);
    }

    private JButton createButton(String text, ActionListener actionListener) {
        JButton button = new JButton(text);
        button.setBackground(new Color(236, 178, 98));
        button.addActionListener(actionListener);
        return button;
    }

    private void MPPActionPerformed(java.awt.event.ActionEvent evt) {
        ManagePersonalProfile personal_profile_frame = new ManagePersonalProfile();
        personal_profile_frame.setVisible(true);
        personal_profile_frame.pack();
        personal_profile_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    private void btn_manage_salesquotationActionPerformed(java.awt.event.ActionEvent evt) {
        ManageSaleOrderQuotationFrame manage_sales_quotation_frame = new ManageSaleOrderQuotationFrame();
        manage_sales_quotation_frame.setVisible(true);
        manage_sales_quotation_frame.pack();
        manage_sales_quotation_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    private void btn_returnActionPerformed(java.awt.event.ActionEvent evt) {
        MainWindow login_frame = new MainWindow();
        login_frame.setVisible(true);
        login_frame.pack();
        login_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    private void btn_find_personal_salesActionPerformed(java.awt.event.ActionEvent evt) {
        FindPersonalSalesOrder find_personal_sales_frame = new FindPersonalSalesOrder();
        find_personal_sales_frame.setVisible(true);
        find_personal_sales_frame.pack();
        find_personal_sales_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SalespersonDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SalespersonDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SalespersonDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SalespersonDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SalespersonDashboard().setVisible(true);
            }
        });
    }
}
