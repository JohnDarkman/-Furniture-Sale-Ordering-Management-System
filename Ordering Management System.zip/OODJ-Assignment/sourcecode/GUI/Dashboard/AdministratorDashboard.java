package GUI.Dashboard;

import GUI.Profile.ManagePersonalProfile;
import GUI.Profile.FindWorkerProfile;
import GUI.generateReport.GenerateReportMenu;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import GUI.MainWindow;

public class AdministratorDashboard extends javax.swing.JFrame {

    private javax.swing.JButton admin_manageprofile_btn;
    private javax.swing.JButton btn_login;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;

    public AdministratorDashboard() {
        initComponents();
    }

    private void initComponents() {
        admin_manageprofile_btn = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btn_login = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(MainWindow.WIDTH, MainWindow.HEIGHT));
        setResizable(false);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(214, 140, 51));
        JLabel titleLabel = new JLabel("Administrator Dashboard");
        titleLabel.setFont(new Font("Microsoft PhagsPa", Font.BOLD, 48));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);

        // Content Panel
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(Color.WHITE);

        admin_manageprofile_btn = createButton("Manage Profile");
        jButton1 = createButton("Manage Worker Profile");
        jButton2 = createButton("Generate Report");
        btn_login = createButton("Back To Login");

        admin_manageprofile_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admin_manageprofile_btnActionPerformed(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        contentPanel.add(admin_manageprofile_btn, gbc);
        gbc.gridy++;
        contentPanel.add(jButton1, gbc);
        gbc.gridy++;
        contentPanel.add(jButton2, gbc);
        gbc.gridy++;
        contentPanel.add(btn_login, gbc);

        // Adding components to the main frame
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(51, 51, 51));
        button.setFont(new Font("Microsoft PhagsPa", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        return button;
    }

    private void admin_manageprofile_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_admin_manageprofile_btnActionPerformed
        ManagePersonalProfile personal_profile_frame = new ManagePersonalProfile();
        personal_profile_frame.setVisible(true);
        personal_profile_frame.pack();
        personal_profile_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        FindWorkerProfile worker_profile_frame = new FindWorkerProfile();
        worker_profile_frame.setVisible(true);
        worker_profile_frame.pack();
        worker_profile_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        GenerateReportMenu report_menu_frame = new GenerateReportMenu();
        report_menu_frame.setVisible(true);
        report_menu_frame.pack();
        report_menu_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {
        MainWindow login_frame = new MainWindow();
        login_frame.setVisible(true);
        login_frame.pack();
        login_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdministratorDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdministratorDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdministratorDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdministratorDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdministratorDashboard().setVisible(true);
            }
        });
    }
}
