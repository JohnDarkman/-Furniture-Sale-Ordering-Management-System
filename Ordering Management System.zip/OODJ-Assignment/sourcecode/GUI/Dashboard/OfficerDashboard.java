
package GUI.Dashboard;

import GUI.ProcessSaleOrder.ProcessSaleOrder;
import GUI.Profile.ManagePersonalProfile;
import GUI.generateReport.GenerateReportMenu;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import GUI.MainWindow;

public class OfficerDashboard extends javax.swing.JFrame {
    private JButton btn_manageprofile, btn_process_sale_order, btn_generate_report, btn_returnToLogin;

    public OfficerDashboard() {
        initComponents();
        setLayout(new BorderLayout());
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(MainWindow.WIDTH, MainWindow.HEIGHT));
        setResizable(false);

        JPanel jPanel1 = new JPanel();
        jPanel1.setLayout(new BorderLayout());

        JPanel jPanel2 = new JPanel();
        jPanel2.setBackground(new Color(214, 140, 51));
        JLabel jLabel1 = new JLabel("Officer Dashboard");
        jLabel1.setFont(new Font("Microsoft PhagsPa", Font.BOLD, 48));
        jLabel1.setForeground(Color.WHITE);
        jPanel2.add(jLabel1);

        jPanel1.add(jPanel2, BorderLayout.NORTH);

        JPanel jPanel3 = new JPanel(new GridBagLayout());
        jPanel3.setBackground(Color.WHITE);

        btn_manageprofile = createButton("Manage Profile", this::btn_manageprofileActionPerformed);
        btn_process_sale_order = createButton("Process Sale Order", this::btn_process_sale_orderActionPerformed);
        btn_generate_report = createButton("Generate Report", this::btn_generate_reportActionPerformed);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;

        jPanel3.add(btn_manageprofile, gbc);
        gbc.gridx++;
        jPanel3.add(btn_process_sale_order, gbc);
        gbc.gridx++;
        jPanel3.add(btn_generate_report, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;

        JLabel jLabel2 = new JLabel("Manage Personal Profile");
        JLabel jLabel3 = new JLabel("Manage Sale Orders");
        JLabel jLabel4 = new JLabel("Generate Report");

        jPanel3.add(jLabel2, gbc);
        gbc.gridx++;
        jPanel3.add(jLabel3, gbc);
        gbc.gridx++;
        jPanel3.add(jLabel4, gbc);

        gbc.gridx++;
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 3;

        btn_returnToLogin = createButton("Back to Login", this::btn_returnToLoginActionPerformed);
        jPanel3.add(btn_returnToLogin, gbc);

        jPanel1.add(jPanel3, BorderLayout.CENTER);

        getContentPane().add(jPanel1);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton createButton(String text, ActionListener actionListener) {
        JButton button = new JButton(text);
        button.setBackground(new Color(102, 102, 102));
        button.addActionListener(actionListener);
        return button;
    }

    private void btn_manageprofileActionPerformed(java.awt.event.ActionEvent evt) {
        ManagePersonalProfile personal_profile_frame = new ManagePersonalProfile();
        personal_profile_frame.setVisible(true);
        personal_profile_frame.pack();
        personal_profile_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    private void btn_process_sale_orderActionPerformed(java.awt.event.ActionEvent evt) {
        ProcessSaleOrder manage_order_frame = new ProcessSaleOrder();
        manage_order_frame.setVisible(true);
        manage_order_frame.pack();
        manage_order_frame.setLocationRelativeTo(null);
        this.dispose();
        
    }

    private void btn_returnToLoginActionPerformed(java.awt.event.ActionEvent evt) {
        MainWindow login_frame = new MainWindow();
        login_frame.setVisible(true);
        login_frame.pack();
        login_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    private void btn_generate_reportActionPerformed(java.awt.event.ActionEvent evt) {
        GenerateReportMenu generate_report_frame = new GenerateReportMenu();
        generate_report_frame.setVisible(true);
        generate_report_frame.pack();
        generate_report_frame.setLocationRelativeTo(null);
        this.dispose();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OfficerDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OfficerDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OfficerDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OfficerDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OfficerDashboard().setVisible(true);
            }
        });
    }
}
