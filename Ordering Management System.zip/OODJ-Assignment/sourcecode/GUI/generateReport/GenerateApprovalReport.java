package GUI.generateReport;

import static InputOutput.CSVDataReader.readReportsFromCSV;
import Reports.ApprovalReport;
import UserProfile.Session.SessionManager;
import UserProfile.User;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import static searchAlgo.CSVSearch.findApprovalReportByOrderID;

public class GenerateApprovalReport extends javax.swing.JFrame {

    public GenerateApprovalReport() {
        initComponents();
        populateExistingTable();
    }

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btn_return = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        tf_order_id = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btn_approve_saleorder = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(810, 550));

        jPanel1.setBackground(new java.awt.Color(214, 140, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 207, 149));

        jLabel1.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(53, 79, 82));
        jLabel1.setText("Approve Sale Order");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(231, 231, 231)
                .addComponent(jLabel1)
                .addContainerGap(240, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(35, 35, 35))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 800, 120);

        jPanel3.setBackground(new java.awt.Color(53, 79, 82));

        btn_return.setBackground(new java.awt.Color(255, 207, 149));
        btn_return.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_return.setForeground(new java.awt.Color(53, 79, 82));
        btn_return.setText("Back");
        btn_return.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_returnActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 207, 149));
        jLabel2.setText("Enter Sale Order ID");

        tf_order_id.setBackground(new java.awt.Color(255, 255, 204));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Sale Order ID", "Status"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btn_approve_saleorder.setBackground(new java.awt.Color(255, 207, 149));
        btn_approve_saleorder.setFont(new java.awt.Font("Microsoft PhagsPa", 1, 18)); // NOI18N
        btn_approve_saleorder.setForeground(new java.awt.Color(53, 79, 82));
        btn_approve_saleorder.setText("Approve");
        btn_approve_saleorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_approve_saleorderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_return, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(tf_order_id, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(btn_approve_saleorder, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 517, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(tf_order_id, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_approve_saleorder, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(btn_return, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 120, 800, 380);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 135, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 120, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_returnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_returnActionPerformed
        GenerateReportMenu report_menu_frame = new GenerateReportMenu();
        report_menu_frame.setVisible(true);
        report_menu_frame.pack();
        report_menu_frame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btn_returnActionPerformed

    private void btn_approve_saleorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_approve_saleorderActionPerformed
        //get session manager data
        User current_user = SessionManager.getCurrentUser();
        
        //obtain data from csv file,create objects and add to arraylist
        ArrayList<ApprovalReport> approval_report_list = readReportsFromCSV("ApprovalReportData.csv");
        // get the sale order id from the text field
        String entered_sale_order_id = tf_order_id.getText();
        // validate and verify the entered id and create the obj of the found report
        ApprovalReport found_report = findApprovalReportByOrderID(approval_report_list,entered_sale_order_id);
        
        //set the data to the approval report
        found_report.setApprovalReportID(found_report.generateReportID(current_user.getUsername()));
        found_report.setStatus("Approved");
        found_report.setDoneByUsername(current_user.getUsername());
        found_report.setDoneByRole(current_user.getRole());
        
        //replace old data with new data
        updateApprovalReportInCSV(approval_report_list, found_report,"ApprovalReportData.csv");
        
        //display new data on table
        
        
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        tblModel.setRowCount(0); // Clear existing rows
        
        
          for (ApprovalReport report : approval_report_list) {
            
            String order_id = report.getSaleOrderID();
            String status_id = report.getStatus();
            
            String data[] = {order_id,status_id};
            tblModel.addRow(data);
            
        }

        
    }//GEN-LAST:event_btn_approve_saleorderActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GenerateApprovalReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GenerateApprovalReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GenerateApprovalReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GenerateApprovalReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GenerateApprovalReport().setVisible(true);
            }
        });
    }
    
    private void populateExistingTable() {
        // Method not yet made
        ArrayList<ApprovalReport> approval_report_list = readReportsFromCSV("ApprovalReportData.csv");
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        tblModel.setRowCount(0); // Clear existing rows
        
        for (ApprovalReport report : approval_report_list) {
            
            String order_id = report.getSaleOrderID();
            String status_id = report.getStatus();
            
            String data[] = {order_id,status_id};
            tblModel.addRow(data);
            
        }
        
    }
    
    public void updateApprovalReportInCSV(ArrayList<ApprovalReport> approval_report_list, ApprovalReport updated_report, String csvFileName) {
    // Find the index of the updated report in the list
    int index = -1;
    for (int i = 0; i < approval_report_list.size(); i++) {
        ApprovalReport report = approval_report_list.get(i);
        if (report.getApprovalReportID().equals(updated_report.getApprovalReportID())) {
            index = i;
            break;
        }
    }
    
    // Replace the old report with the updated one
    if (index != -1) {
        approval_report_list.set(index, updated_report);
        
        // Write the updated list back to the CSV file
        writeApprovalReportToCSV("ApprovalReportData.csv",approval_report_list);
    } else {
        System.out.println("Report not found in the list.");
    }
}

    private void writeApprovalReportToCSV(String filename, ArrayList<ApprovalReport> report_list) {
    try (FileWriter csvWriter = new FileWriter(filename)) {
        for (ApprovalReport report : report_list) {
            csvWriter.append(report.getApprovalReportID())
                    .append(",")
                    .append(report.getSaleOrderID())
                    .append(",")
                    .append(report.getCustomerName())
                    .append(",")
                    .append(report.getStatus())
                    .append(",")
                    .append(report.getDoneByUsername())
                    .append(",")
                    .append(report.getDoneByRole())
                    .append("\n");
        }
        csvWriter.flush();
    } catch (IOException e) {
        e.printStackTrace(); // Handle IOException more appropriately, like logging or displaying an error message.
    }
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_approve_saleorder;
    private javax.swing.JButton btn_return;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField tf_order_id;
    // End of variables declaration//GEN-END:variables
}
