package GUI;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainWindow extends JFrame {
    public static int WIDTH = 720;
    public static int HEIGHT = 512;

    JPanel authPanel = new AuthPanel(this);
    // JPanel dashboardPanel = new JPanel();
    // JPanel reportPanel = new JPanel();
    // JPanel manageSaleOrderQuotationPanel = new JPanel();
    // JPanel processSaleOrderPanel = new JPanel();
    // JPanel profilePanel = new JPanel();
    // JPanel viewPersonalSalesOrderPanel = new JPanel();

    public MainWindow() {
        setTitle("Crafted Comfort");
        add(authPanel, BorderLayout.WEST);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        MainWindow frame = new MainWindow();
        frame.setVisible(true);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setSize(MainWindow.WIDTH, MainWindow.HEIGHT);
        frame.setResizable(false);
    }
}