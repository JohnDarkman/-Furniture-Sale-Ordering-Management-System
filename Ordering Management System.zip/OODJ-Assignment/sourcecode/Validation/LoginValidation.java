
package Validation;

import UserProfile.User;
import java.util.ArrayList;

public class LoginValidation {
    
   // Implement the user login validation logic
    public static boolean validateLogin(ArrayList<User> users, String enteredEmail, String enteredPassword) {
        for (User user : users) {
            if (user.getEmail_Address().equals(enteredEmail) && user.getPassword().equals(enteredPassword)) {
                return true; // Login is successful
            }
        }
        return false; // Login has failed bruh
    }
    
     // Implement the worker search logic
    public static boolean validateWorkerEmail(ArrayList<User> users, String Email) {
        for (User user : users) {
            if (user.getEmail_Address().equals(Email)) {
                return true; // Search is successful
            }
        }
        return false; // search has failed bruh
    }
    
}
