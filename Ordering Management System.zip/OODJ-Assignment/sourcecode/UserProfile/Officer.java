
package UserProfile;

public class Officer extends User {
    
    private int officer_ID;
    
    public Officer(String Username, String Email_Address, String Password, String Role) {
        super(Username, Email_Address, Password, Role);
    }
    
       public int getOfficer_ID() {
        return officer_ID;
    }

    public void setOfficer_ID(int officer_ID) {
        this.officer_ID = officer_ID;
    }
    
}



