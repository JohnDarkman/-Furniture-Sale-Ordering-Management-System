
package UserProfile;

public class User {
    
    private String Username;
    private String Email_Address;
    private String Password;
    private String Role;

    public User(String Username, String Email_Address, String Password,String Role) {
        this.Username = Username;
        this.Password = Password;
        this.Email_Address = Email_Address;
        this.Role = Role;
    }
    
    @Override
    public String toString() {
        return "User{" +
                "Username='" + Username + '\'' +
                ", Email='" + Email_Address + '\'' +
                ", Password='" + Password + '\'' +
                ", Role='" + Role + '\'' +
                '}';
    }
    
    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getEmail_Address() {
        return Email_Address;
    }

    public void setEmail_Address(String email_Address) {
        Email_Address = email_Address;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }
    
}
