
package UserProfile.Session;

import SaleOrder.SaleOrderQuotation;

public class SessionSalesOrder {
    
    private static SaleOrderQuotation current_order;
    
    
    public static void setCurrentOrder(SaleOrderQuotation order) {
        current_order = order;
    }

    public static SaleOrderQuotation getCurrentOrder() {
        return current_order;
    }

    public static void clearSession() {
        current_order = null;
    }
    
}
