
package UserProfile;

public class Salesperson extends User {
    
    private int salesperson_ID;
    
    public Salesperson(String Username, String Email_Address, String Password, String Role) {
        super(Username, Email_Address, Password, Role);
    }
    
    public int getSalesperson_ID(){
        return salesperson_ID;
    }
    
    public void setSalesperson_ID(int salesperson_ID){
        this.salesperson_ID = salesperson_ID;
    }
}
