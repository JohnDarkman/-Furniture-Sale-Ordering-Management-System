
package UserProfile;

public class Administrator extends User {
    
    private int admin_ID;
    
    public Administrator(String Username, String Email_Address, String Password, String Role) {
        super(Username, Email_Address, Password, Role);
    }
    
       public int getAdmin_ID() {
        return admin_ID;
    }

    public void setAdmin_ID(int admin_ID) {
        this.admin_ID = admin_ID;
    }

}
    
