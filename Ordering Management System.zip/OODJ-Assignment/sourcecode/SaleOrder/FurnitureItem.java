package SaleOrder;

public class FurnitureItem {
    
    private String furniture_id;
    private String furniture_name;
    private String furniture_type;
    private double rate;
    private double delivery;
    private double sale;
    private double furniture_price;
    
    public FurnitureItem(String furniture_id,String name, String type, double rate, double delivery, double sale, double price){
        this.furniture_id = furniture_id;
        this.furniture_name = name;
        this.furniture_type = type;
        this.rate = rate;
        this.delivery = delivery;
        this.sale = sale;
        this.furniture_price = price;
    }

    // Getters
    public String getFurniture_ID() {
        return furniture_id;
    }
    
    public String getFurnitureName() {
        return furniture_name;
    }

    public String getFurnitureType() {
        return furniture_type;
    }

    public double getRate() {
        return rate;
    }

    public double getDelivery() {
        return delivery;
    }

    public double getSale() {
        return sale;
    }

    public double getFurniturePrice() {
        return furniture_price;
    }

    // Setters
    public void setFurnitureID(String furniture_id){
        this.furniture_id = furniture_id;
    }
    
    public void setFurnitureName(String name) {
        this.furniture_name = name;
    }

    public void setFurnitureType(String type) {
        this.furniture_type = type;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public void setDelivery(double delivery) {
        this.delivery = delivery;
    }

    public void setSale(double sale) {
        this.sale = sale;
    }

    public void setFurniturePrice(double price) {
        this.furniture_price = price;
    }
    
    public String toString() {
    return "Furniture ID: " + furniture_id;
}
    
    
}
