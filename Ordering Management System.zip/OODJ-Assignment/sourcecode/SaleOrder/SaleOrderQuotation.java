package SaleOrder;

import Reports.ApprovalReport;
import java.util.ArrayList;

public class SaleOrderQuotation {

    private String salesperson_username; // to be used for listing all of a particlular salesperson's order
    private String sale_order_ID; //unique identifier for each sales order
    private String customer_name; // additional data
    private String customer_address; // additional data
    private String customer_email; // additional data
    private String created_date; // addtional data
    private ArrayList<FurnitureItem> item_list; // container for storing all of the furnitures added for the order
    private ApprovalReport approvalReport; // Composition
    private String status_flag = "Sale Order"; // flag

    // First Constructor
    public SaleOrderQuotation(String salesperson_username, String sale_order_ID, String customer_name,
            String customer_address, String customer_email, String created_date, ArrayList<FurnitureItem> item_list) {
        this.salesperson_username = salesperson_username;
        this.sale_order_ID = sale_order_ID;
        this.customer_name = customer_name;
        this.customer_address = customer_address;
        this.customer_email = customer_email;
        this.created_date = created_date;
        this.item_list = item_list;

        // Initialize the reports
        this.approvalReport = new ApprovalReport(sale_order_ID,customer_name);
    }
    
    // Second Constructor 
    public SaleOrderQuotation(String salesperson_username, String sale_order_ID, String customer_name,
            String customer_address, String customer_email, String created_date, ArrayList<FurnitureItem> item_list, ApprovalReport report){
        this.salesperson_username = salesperson_username;
        this.sale_order_ID = sale_order_ID;
        this.customer_name = customer_name;
        this.customer_address = customer_address;
        this.customer_email = customer_email;
        this.created_date = created_date;
        this.item_list = item_list;
        this.approvalReport = report;
    }

    // Getter and Setter methods for sale_order_ID
    public String getSale_order_ID() {
        return sale_order_ID;
    }

    public void setSale_order_ID(String sale_order_ID) {
        this.sale_order_ID = sale_order_ID;
    }

    // Getter and Setter methods for customer_name
    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    // Getter and Setter methods for customer_address
    public String getCustomer_address() {
        return customer_address;
    }

    public void setCustomer_address(String customer_address) {
        this.customer_address = customer_address;
    }

    // Getter and Setter methods for customer_email
    public String getCustomer_email() {
        return customer_email;
    }

    public void setCustomer_email(String customer_email) {
        this.customer_email = customer_email;
    }

    // Getter and Setter methods for completion_date
    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    // Getter and Setter methods for salesperson_username
    public String getSalesperson_username() {
        return salesperson_username;
    }

    public void setSalesperson_username(String salesperson_username) {
        this.salesperson_username = salesperson_username;
    }

    // Getter and Setter methods for item_list
    public ArrayList<FurnitureItem> getItem_list() {
        return item_list;
    }

    public void setItem_list(ArrayList<FurnitureItem> item_list) {
        this.item_list = item_list;
    }

    // Getter and Setter methods for approvalReport
    public ApprovalReport getApprovalReport() {
        return approvalReport;
    }

    public void setApprovalReport(ApprovalReport approvalReport) {
        this.approvalReport = approvalReport;
    }
    
    public String getStatusFlag(){
        return status_flag;
    }
    
    public void setStatusFlag(String status_flag){
        this.status_flag = status_flag;
    }
    
}
