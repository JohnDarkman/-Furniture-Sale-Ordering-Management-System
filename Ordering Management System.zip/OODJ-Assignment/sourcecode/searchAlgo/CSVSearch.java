
package searchAlgo;

import Reports.ApprovalReport;
import SaleOrder.FurnitureItem;
import SaleOrder.SaleOrderQuotation;
import UserProfile.User;

import java.util.ArrayList;

public class CSVSearch {
    
    public static User findUserByEmail(ArrayList<User> users, String email) {
    for (User user : users) {
        if (user.getEmail_Address().equals(email)) {
            return user;
        }
    }
        return null;
  }
    
    public static User findUserByUsername(ArrayList<User> users, String Username) {
    for (User user : users) {
        if (user.getUsername().equals(Username)) {
            return user;
        }
    }
        return null;
  }
    
    public static FurnitureItem findItemByFurnitureID(ArrayList<FurnitureItem> Item_list, String furniture_ID) {
        
        for (FurnitureItem item : Item_list) {
            System.out.println("Checking item: " + item); // Debug line
            if (item != null && item.getFurniture_ID() != null && item.getFurniture_ID().equals("\"" + furniture_ID + "\"")) {
                System.out.println("Item obtained :D");
                return item;
            }
        }
        System.out.println("Item not found");
        return null;
    }
    
    public static SaleOrderQuotation findSaleOrderByOrderID(ArrayList<SaleOrderQuotation> order_list, String sale_order_id){
        for(SaleOrderQuotation quotation : order_list){
            if(quotation.getSale_order_ID().equals(sale_order_id)){
                System.out.println("Item found, returning sale order");
                return quotation;
            }
        }
        return null;
    }

    public static ApprovalReport findApprovalReportByOrderID(ArrayList<ApprovalReport> report_list, String sale_order_id){
        for(ApprovalReport report : report_list){
            if(report.getSaleOrderID().equals(sale_order_id)){
                System.out.println("Item found, returning report");
                return report;
            }
        }
        return null;
    }
}
