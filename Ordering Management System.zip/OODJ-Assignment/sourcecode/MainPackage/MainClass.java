
package MainPackage;

import GUI.MainWindow;

public class MainClass {

    public static void main(String[] args) {
        
        MainWindow login_frame = new MainWindow();
        login_frame.setVisible(true);
        login_frame.pack();
        login_frame.setLocationRelativeTo(null);
    }
    
}
