
package Reports;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class ApprovalReport {
    
    private String approval_report_ID;
    private String sale_order_ID; //will be used to match the sales order record
    private String customer_name; //will be used to match the sales order record
    private String status; //either processing or complete
    private String done_by_username;
    private String done_by_role;
    
    //constructor to be used when instantiating sale order quotation object
    public ApprovalReport(String sale_order_ID, String customer_name){
        this.sale_order_ID = sale_order_ID;
        this.customer_name = customer_name;
        this.status = "Processing";
    }
    
    //constructor to be used when creating report object from csv file
    public ApprovalReport(String approval_report_ID, String sale_order_ID, String customer_name, String status,
            String done_by_username, String done_by_role){
        this.approval_report_ID = approval_report_ID;
        this.sale_order_ID = sale_order_ID;
        this.customer_name = customer_name;
        this.status = status;
        this.done_by_username = done_by_username;
        this.done_by_role = done_by_role;
        
    }
    
     // Getter and setter for approval_report_ID
    public String getApprovalReportID() {
        return approval_report_ID;
    }

    public void setApprovalReportID(String approval_report_ID) {
        this.approval_report_ID = approval_report_ID;
    }

    // Getter and setter for sale_order_ID
    public String getSaleOrderID() {
        return sale_order_ID;
    }

    public void setSaleOrderID(String sale_order_ID) {
        this.sale_order_ID = sale_order_ID;
    }

    // Getter and setter for customer_name
    public String getCustomerName() {
        return customer_name;
    }

    public void setCustomerName(String customer_name) {
        this.customer_name = customer_name;
    }

    // Getter and setter for status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Getter and setter for done_by_username
    public String getDoneByUsername() {
        return done_by_username;
    }

    public void setDoneByUsername(String done_by_username) {
        this.done_by_username = done_by_username;
    }

    // Getter and setter for done_by_role
    public String getDoneByRole() {
        return done_by_role;
    }

    public void setDoneByRole(String done_by_role) {
        this.done_by_role = done_by_role;
    }
    
    // generate report ID method for approval and work done reports 
    public String generateReportID(String officer_admin_name){
        String usernamePrefix = officer_admin_name.substring(0, Math.min(officer_admin_name.length(), 3));

        // Get current timestamp
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = dateFormat.format(new Date());

        // Generate a random number (you can customize the range as needed)
        Random random = new Random();
        int randomNumber = random.nextInt(10000); // Example: 4-digit random number

        // Combine username prefix, timestamp, and random number to create a unique ID
        return usernamePrefix + timestamp + String.format("%04d", randomNumber);
    }
    
}
