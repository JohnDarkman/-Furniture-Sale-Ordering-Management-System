
package InputOutput;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CSVFileCreator {
    
     public static void createCsvFile(String filename) {
        try {
            File file = new File(filename);

            // If the file doesn't exist, create it 
            if (!file.exists()) {
                boolean fileCreated = file.createNewFile();
                if (fileCreated) {
                    System.out.println("File created: " + filename);
                    try (FileWriter csvWriter = new FileWriter(file)) {
                        System.out.println("Creating csvFile");
                        csvWriter.flush();
                        System.out.println("Header written to: " + filename);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    System.out.println("Failed to create file: " + filename);
                }
            } else {
                System.out.println("File already exists: " + filename);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
