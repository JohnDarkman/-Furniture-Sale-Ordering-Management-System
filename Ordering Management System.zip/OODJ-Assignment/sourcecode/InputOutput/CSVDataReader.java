package InputOutput;

import Reports.ApprovalReport;
import SaleOrder.FurnitureItem;
import SaleOrder.SaleOrderQuotation;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import UserProfile.User;
import java.util.Arrays;
import static searchAlgo.CSVSearch.findItemByFurnitureID;

public class CSVDataReader {

    // Test code for reading the data in the csv file
    public static void main(String[] args) {
        // Read User objects from CSV file
        ArrayList<User> users = readUsersFromCSV("Users.csv");

        // Display the created User objects
        for (User user : users) {
            System.out.println(user);
        }
    }

    public static ArrayList<User> readUsersFromCSV(String filename) {
        ArrayList<User> users = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                // Create user objects based on the CSV data
                User user = createUsersFromCSV(data);
                if (user != null) {
                    users.add(user);
                }
            }
        } catch (IOException e) {
            // Handle IOException
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }

        return users;
    }
    
    public static ArrayList<ApprovalReport> readReportsFromCSV(String filename) {
        ArrayList<ApprovalReport> report_list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                // Create user objects based on the CSV data
                ApprovalReport report = createApprovalReportFromCSV(data);
                if (report != null) {
                    report_list.add(report);
                }
            }
        } catch (IOException e) {
            // Handle IOException
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
        return report_list;
    }
    
    public static ArrayList<FurnitureItem> readFurnitureItemsFromCSV(String filename) {
    ArrayList<FurnitureItem> item_list = new ArrayList<>();

    try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
        // Read the header line (skipping it)
        br.readLine();

        String line;
        while ((line = br.readLine()) != null) {
            // After reading each line in readFurnitureItemsFromCSV method
            String[] data = line.split(",");

            // Create user objects based on the CSV data
            FurnitureItem item = createFurnitureItemFromCSV(data); // MAYBE HERE
            if (item != null) {
                System.out.println("Item is added to csv_item_list");
                item_list.add(item);
            }
        }
    } catch (IOException e) {
        // Handle IOException
        System.out.println("An error occurred while reading the file: " + e.getMessage());
    }

    return item_list;
}
    
    public static ArrayList<SaleOrderQuotation> readSaleOrderQuotationFromCSV(String filename){
        ArrayList<SaleOrderQuotation> order_quotation_list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                // Create user objects based on the CSV data
                SaleOrderQuotation order_quotation = createSaleOrderQuotationFromCSV(data);
                if (order_quotation != null) {
                    order_quotation_list.add(order_quotation);
                }
            }
        } catch (IOException e) {
            // Handle IOException
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }

        return order_quotation_list;
    }


    private static User createUsersFromCSV(String[] data) {
        if (data.length == 4) {
            // Extract data from CSV and create a User object
            String username = data[0].trim();
            String email = data[1].trim();
            String password = data[2].trim();
            String role = data[3].trim();
            return new User(username, email, password, role);
        } else {
            // Handle invalid data or format
            System.out.println("Invalid data in CSV: ");
            return null;
        }
    }
    
    private static ApprovalReport createApprovalReportFromCSV(String[] data) {
        if (data.length == 6) {
            // Extract data from CSV and create a User object
            String approval_report_id = data[0].trim();
            String sale_order_id = data[1].trim();
            String customer_name = data[2].trim();
            String status = data[3].trim();
            String done_by_username = data[4].trim();
            String done_by_role = data[5].trim();
            return new ApprovalReport(approval_report_id,sale_order_id, customer_name, status, done_by_username, done_by_role);
        } else {
            // Handle invalid data or format
            System.out.println("Invalid data in CSV: ");
            return null;
        }
    }
    
    private static FurnitureItem createFurnitureItemFromCSV(String[] data) {
        String lineitemID = "test"; // Local variable to track line number

        switch (data.length) {
            case 7:
                try {
                    lineitemID = data[0].trim();
                    String furniture_id = data[0].trim();
                    String furniture_name = data[1].trim();
                    String furniture_type = data[2].trim();

                    // Check for "NA" in the rate column
                    double furniture_rate;
                    if ("NA".equalsIgnoreCase(data[3].trim())) {
                        furniture_rate = 0; // or handle it differently based on your requirements
                    } else {
                        furniture_rate = Double.parseDouble(data[3].trim());
                    }
                
                    double furniture_delivery = Double.parseDouble(data[4].trim());
                    double furniture_sale = Double.parseDouble(data[5].trim());

                    // Check for "NA" in the price column
                    double furniture_price;
                    if ("NA".equalsIgnoreCase(data[6].trim())) {
                        furniture_price = 1000; // assume price is 1000 if value is "NA"
                    } else {
                        furniture_price = Double.parseDouble(data[6].trim());
                    }


                    return new FurnitureItem(furniture_id, furniture_name, furniture_type, furniture_rate, furniture_delivery, furniture_sale, furniture_price);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Error parsing data at line " + lineitemID + ": " + e.getMessage());
                    System.out.println("Failed to create Item");
                    System.out.println("line with length: " + data.length);
                    System.out.println(" ");

                    return null; // Handle the error or return null
                }
            case 8:
                try {
                    lineitemID = data[0].trim();
                    String furniture_id = data[0].trim();
                    String furniture_name = combineNameColumns(data,1,2);
                    String furniture_type = data[3].trim();

                    // Check for "NA" in the rate column
                    double furniture_rate;
                    if ("NA".equalsIgnoreCase(data[4].trim())) {
                        furniture_rate = 0; // or handle it differently based on your requirements
                    } else {
                        furniture_rate = Double.parseDouble(data[4].trim());
                    }
                
                    double furniture_delivery = Double.parseDouble(data[5].trim());
                    double furniture_sale = Double.parseDouble(data[6].trim());

                    // Check for "NA" in the price column
                    double furniture_price;
                    if ("NA".equalsIgnoreCase(data[6].trim())) {
                        furniture_price = 1000; // assume price is 1000 if value is "NA"
                    } else {
                        furniture_price = Double.parseDouble(data[6].trim());
                    }


                    return new FurnitureItem(furniture_id, furniture_name, furniture_type, furniture_rate, furniture_delivery, furniture_sale, furniture_price);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Error parsing data at line " + lineitemID + ": " + e.getMessage());
                    System.out.println("Failed to create Item");
                    System.out.println("line with length: " + data.length);
                    System.out.println(" ");

                    return null; // Handle the error or return null
                }
            case 9:
                try {
                    lineitemID = data[0].trim();
                    String furniture_id = data[0].trim();
                    String furniture_name = combineNameColumns(data,1,3);
                    String furniture_type = data[4].trim();

                    // Check for "NA" in the rate column
                    double furniture_rate;
                    if ("NA".equalsIgnoreCase(data[5].trim())) {
                        furniture_rate = 0; // or handle it differently based on your requirements
                    } else {
                        furniture_rate = Double.parseDouble(data[5].trim());
                    }
                
                    double furniture_delivery = Double.parseDouble(data[6].trim());
                    double furniture_sale = Double.parseDouble(data[7].trim());

                    // Check for "NA" in the price column
                    double furniture_price;
                    if ("NA".equalsIgnoreCase(data[6].trim())) {
                        furniture_price = 1000; // assume price is 1000 if value is "NA"
                    } else {
                        furniture_price = Double.parseDouble(data[6].trim());
                    }


                    // Return or use the additionalField as needed
                    return new FurnitureItem(furniture_id, furniture_name, furniture_type, furniture_rate, furniture_delivery, furniture_sale, furniture_price);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Error parsing data at line " + lineitemID + ": " + e.getMessage());
                    System.out.println("Failed to create Item");
                    System.out.println("line with length: " + data.length);
                    System.out.println(" ");

                    return null; // Handle the error or return null
                }
            case 10:
                try {
                    lineitemID = data[0].trim();
                    String furniture_id = data[0].trim();
                    String furniture_name = combineNameColumns(data,1,4);
                    String furniture_type = data[5].trim();

                    // Check for "NA" in the rate column
                    double furniture_rate;
                    if ("NA".equalsIgnoreCase(data[6].trim())) {
                        furniture_rate = 0; // or handle it differently based on your requirements
                    } else {
                        furniture_rate = Double.parseDouble(data[6].trim());
                    }
                
                    double furniture_delivery = Double.parseDouble(data[7].trim());
                    double furniture_sale = Double.parseDouble(data[8].trim());

                    // Check for "NA" in the price column
                    double furniture_price;
                    if ("NA".equalsIgnoreCase(data[9].trim())) {
                        furniture_price = 1000; // assume price is 1000 if value is "NA"
                    } else {
                        furniture_price = Double.parseDouble(data[9].trim());
                    }


                    // Return or use the additionalField as needed
                    return new FurnitureItem(furniture_id, furniture_name, furniture_type, furniture_rate, furniture_delivery, furniture_sale, furniture_price);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Error parsing data at line " + lineitemID + ": " + e.getMessage());
                    System.out.println("Failed to create Item");
                    System.out.println("line with length: " + data.length);
                    System.out.println(" ");

                    return null; // Handle the error or return null
                }
            case 11:
                try {
                    lineitemID = data[0].trim();
                    String furniture_id = data[0].trim();
                    String furniture_name = combineNameColumns(data,1,5);
                    String furniture_type = data[6].trim();

                    // Check for "NA" in the rate column
                    double furniture_rate;
                    if ("NA".equalsIgnoreCase(data[7].trim())) {
                        furniture_rate = 0; // or handle it differently based on your requirements
                    } else {
                        furniture_rate = Double.parseDouble(data[7].trim());
                    }
                
                    double furniture_delivery = Double.parseDouble(data[8].trim());
                    double furniture_sale = Double.parseDouble(data[9].trim());

                    // Check for "NA" in the price column
                    double furniture_price;
                    if ("NA".equalsIgnoreCase(data[10].trim())) {
                        furniture_price = 1000; // assume price is 1000 if value is "NA"
                    } else {
                        furniture_price = Double.parseDouble(data[10].trim());
                    }

                    // Return or use the additionalField as needed
                    return new FurnitureItem(furniture_id, furniture_name, furniture_type, furniture_rate, furniture_delivery, furniture_sale, furniture_price);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Error parsing data at line " + lineitemID + ": " + e.getMessage());
                    System.out.println("Failed to create Item");
                    System.out.println("line with length: " + data.length);
                    System.out.println(" ");

                    return null; // Handle the error or return null
                }
            case 12:
                try {
                    lineitemID = data[0].trim();
                    String furniture_id = data[0].trim();
                    String furniture_name = combineNameColumns(data,1,6);
                    String furniture_type = data[7].trim();

                    // Check for "NA" in the rate column
                    double furniture_rate;
                    if ("NA".equalsIgnoreCase(data[8].trim())) {
                        furniture_rate = 0; // or handle it differently based on your requirements
                    } else {
                        furniture_rate = Double.parseDouble(data[8].trim());
                    }
                
                    double furniture_delivery = Double.parseDouble(data[9].trim());
                    double furniture_sale = Double.parseDouble(data[10].trim());

                    // Check for "NA" in the price column
                    double furniture_price;
                    if ("NA".equalsIgnoreCase(data[11].trim())) {
                        furniture_price = 1000; // assume price is 1000 if value is "NA"
                    } else {
                        furniture_price = Double.parseDouble(data[11].trim());
                    }

                    // Return or use the additionalField as needed
                    return new FurnitureItem(furniture_id, furniture_name, furniture_type, furniture_rate, furniture_delivery, furniture_sale, furniture_price);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Error parsing data at line " + lineitemID + ": " + e.getMessage());
                    System.out.println("Failed to create Item");
                    System.out.println("line with length: " + data.length);
                    System.out.println(" ");

                    return null; // Handle the error or return null
                }
            default:
                return null;
        }
    }
    
    // Helper method for whatever method i forgor ;-;
    private static String combineNameColumns(String[] data, int startIndex, int endIndex) {
    StringBuilder nameBuilder = new StringBuilder(data[startIndex].trim());
    for (int i = startIndex + 1; i <= endIndex && i < data.length; i++) {
        nameBuilder.append(", ").append(data[i].trim());
    }
    return nameBuilder.toString();
}
    
    private static SaleOrderQuotation createSaleOrderQuotationFromCSV(String[] data){
        if(data.length >= 7){ // check if the index is 7
            //trim index as sale order quotation attributes
            String salesperson_username = data[0].trim(); // get name
            String sales_order_ID = data[1].trim(); // get sales order id
            String customer_name = data[2].trim(); // get the customer name
            String customer_address = data[3].trim(); // get the customer address
            String customer_email = data[4].trim(); // get the customer email
            String date = data[5].trim(); // get the date of sale order creation
            
            String[] itemsData = Arrays.copyOfRange(data, 6, data.length);

            // Create a list to store Furniture Items from the dataset
            ArrayList<FurnitureItem> complete_item_list = readFurnitureItemsFromCSV("dataset.csv");
            
            //create arraylist to store all the furniture items found in the salesorder
            ArrayList<FurnitureItem> itemsList = new ArrayList<>();
           //loop over items data arraylist
            for (String itemData : itemsData) {
                
                 // Remove double quotes from itemData
                 String cleanedItemData = itemData.replaceAll("\"", "");
                
                FurnitureItem item = findItemByFurnitureID(complete_item_list, cleanedItemData.trim());
                itemsList.add(item);
            }
            System.out.println("Item is successfully created and this createSaleOrderQuotationFromCSV method works");
            return new SaleOrderQuotation(
                    salesperson_username, sales_order_ID, customer_name, customer_address, customer_email, date, itemsList
            );
        }
        return null;
             
        }
}
    
    
  

    

