
package InputOutput;

import static InputOutput.CSVWriter.writeApprovalReportListToCSV;
import Reports.ApprovalReport;
import java.util.ArrayList;

public class CSVDataDeleter {
    
        public void deleteReportFromCSV(ArrayList<ApprovalReport> approval_report_list, String order_ID, String csvFileName) {
    // Find the index of the report to be deleted in the list
        System.out.println("Delete report debug line");
    
    int index = -1;
    for (int i = 0; i < approval_report_list.size(); i++) {
        ApprovalReport report = approval_report_list.get(i);
        if (report.getSaleOrderID().equals(order_ID)) {
            index = i;
            break;
        }
    }
    
    // Delete the report from the list if found
    if (index != -1) {
        approval_report_list.remove(index);
        
        // Write the updated list back to the CSV file
        writeApprovalReportListToCSV(approval_report_list, csvFileName);
        System.out.println("Record Removed");
    } else {
        System.out.println("Report not found in the list.");
    }
}
    
}
