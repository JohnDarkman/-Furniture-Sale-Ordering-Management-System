
package InputOutput;

import Reports.ApprovalReport;
import SaleOrder.FurnitureItem;
import SaleOrder.SaleOrderQuotation;
import java.io.FileWriter;
import java.io.IOException;
import UserProfile.User;
import java.util.ArrayList;

public class CSVWriter {

    public static <T extends User> void writeUserToCSV(T user, String filename) {
        //instantiate the object
        try (FileWriter csvWriter = new FileWriter(filename,true)) {
            // Write data for the single User object
            csvWriter.append(user.getUsername())
                    .append(",")
                    .append(user.getEmail_Address())
                    .append(",")
                    .append(user.getPassword())
                    .append(",")
                    .append(user.getRole())
                    .append("\n");

            csvWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /*public static void writeSaleOrderToCSV(SaleOrderQuotation sale_order, String filename){
        //instantiate the object
        try (FileWriter csvWriter = new FileWriter(filename,true)) {
            // Write data for the single User object
            csvWriter.append(sale_order.getSalesperson_username())
                    .append(",")
                    .append(sale_order.getSale_order_ID())
                    .append(",")
                    .append(sale_order.getCustomer_name())
                    .append(",")
                    .append(sale_order.getCustomer_address())
                    .append(",")
                    .append(sale_order.getCustomer_email())
                    .append(",")
                    .append(sale_order.getCreated_date())
                    .append(",");
                    //append arraylist
                    ArrayList<FurnitureItem> sale_order_items = sale_order.getItem_list();
                    for(FurnitureItem item : sale_order_items){
                        csvWriter.append(item.getFurniture_ID())
                                .append(",");
                    }
                    csvWriter.append("\n");
                    csvWriter.flush();
            csvWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
    
    public static void writeSaleOrderToCSV(SaleOrderQuotation sale_order, String filename) {
    //instantiate the object
    try (FileWriter csvWriter = new FileWriter(filename, true)) {
        // Write data for the single SaleOrderQuotation object
        csvWriter.append(sale_order.getSalesperson_username())
                .append(",")
                .append(sale_order.getSale_order_ID())
                .append(",")
                .append(sale_order.getCustomer_name())
                .append(",")
                .append(sale_order.getCustomer_address())
                .append(",")
                .append(sale_order.getCustomer_email())
                .append(",")
                .append(sale_order.getCreated_date())
                .append(",");
        
        // append arraylist
        ArrayList<FurnitureItem> sale_order_items = sale_order.getItem_list();
        for (int i = 0; i < sale_order_items.size(); i++) {
            FurnitureItem item = sale_order_items.get(i);
            csvWriter.append(item.getFurniture_ID());
            // Append comma if it's not the last item
            if (i < sale_order_items.size() - 1) {
                csvWriter.append(",");
            }
        }
        csvWriter.append("\n");
        csvWriter.flush();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    
    public static void writeSaleOrderListToCSV(ArrayList<SaleOrderQuotation> sale_order_list, String filename){
        
        System.out.println("write sale order list to csv debug line");
        
        //instantiate the object
        try (FileWriter csvWriter = new FileWriter(filename)) {
            // Write data for the single User object
            
            for(SaleOrderQuotation sale_order: sale_order_list){
            csvWriter.append(sale_order.getSalesperson_username())
                    .append(",")
                    .append(sale_order.getSale_order_ID())
                    .append(",")
                    .append(sale_order.getCustomer_name())
                    .append(",")
                    .append(sale_order.getCustomer_address())
                    .append(",")
                    .append(sale_order.getCustomer_email())
                    .append(",")
                    .append(sale_order.getCreated_date())
                    .append(",");
                    //append arraylist
                    ArrayList<FurnitureItem> sale_order_items = sale_order.getItem_list();
                    for(FurnitureItem item : sale_order_items){
                        csvWriter.append(item.getFurniture_ID())
                                .append(",");
                    }
                    csvWriter.append("\n");
                    csvWriter.flush();
            }
            csvWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void writeApprovalReportListToCSV(ArrayList<ApprovalReport> approval_report_list, String filename){
        
        System.out.println("write sale order list to csv debug line");
        
        //instantiate the object
        try (FileWriter csvWriter = new FileWriter(filename)) {
            // Write data for the single User object
            
            for(ApprovalReport report : approval_report_list){
            csvWriter.append(report.getApprovalReportID())
                    .append(",")
                    .append(report.getSaleOrderID())
                    .append(",")
                    .append(report.getCustomerName())
                    .append(",")
                    .append(report.getStatus())
                    .append(",")
                    .append(report.getDoneByUsername())
                    .append(",")
                    .append(report.getDoneByRole())
                    .append(",");
                    csvWriter.append("\n");
                    csvWriter.flush();
            }
            csvWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void writeApprovalReportToCSV(ApprovalReport report_item, String filename) {
    // Instantiate the object
    try (FileWriter csvWriter = new FileWriter(filename,true)) {
        // Write data for the single User object
        csvWriter.append(orElse(report_item.getApprovalReportID(), "N/A"))
                .append(",")
                .append(orElse(report_item.getSaleOrderID(), "N/A"))
                .append(",")
                .append(orElse(report_item.getCustomerName(), "N/A"))
                .append(",")
                .append(orElse(report_item.getStatus(), "N/A"))
                .append(",")
                .append(orElse(report_item.getDoneByUsername(), "N/A"))
                .append(",")
                .append(orElse(report_item.getDoneByRole(), "N/A"));
        csvWriter.append("\n");
        csvWriter.flush();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    // Helper method to replace null values with a placeholder
    private static String orElse(String value, String placeholder) {
        return value != null ? value : placeholder;
    }
}


